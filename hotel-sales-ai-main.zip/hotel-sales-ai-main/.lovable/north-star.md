# Étoile du Nord

Les entreprises qui demandent un séjour groupe obtiennent une décision sur leur demande

## Métrique

Demandes passées en statut « Acceptée » ou « Refusée » chaque semaine
