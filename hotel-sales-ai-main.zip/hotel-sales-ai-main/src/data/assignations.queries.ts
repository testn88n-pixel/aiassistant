// src/data/assignations.queries.ts
import { queryOptions, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";

import {
  claimAssignationFn,
  listAssignationsFn,
  listTeamUsersFn,
  updateAssignationFn,
} from "@/lib/assignations.functions";
import type { DemandeAssignation } from "@/lib/assignations.server";

export const assignationsKey = ["assignations"] as const;
export const teamUsersKey = ["team-users"] as const;

export const assignationsQueryOptions = queryOptions({
  queryKey: assignationsKey,
  queryFn: () => listAssignationsFn(),
});

export function useAssignations() {
  return useQuery(assignationsQueryOptions);
}

export const teamUsersQueryOptions = queryOptions({
  queryKey: teamUsersKey,
  queryFn: () => listTeamUsersFn(),
});

export function useTeamUsers() {
  return useQuery(teamUsersQueryOptions);
}

/** Assigne automatiquement au premier commercial ouvrant */
export function useClaimAssignation() {
  const queryClient = useQueryClient();
  const claimFn = useServerFn(claimAssignationFn);

  return useMutation({
    mutationFn: async (input: {
      demande_id: string;
      user_id?: string | null;
      user_name: string;
      user_email: string;
    }) => {
      return claimFn({ data: input });
    },
    onSuccess: (saved) => {
      queryClient.setQueryData<Record<string, DemandeAssignation>>(assignationsKey, (prev) => ({
        ...prev,
        [saved.demande_id]: saved,
      }));
    },
  });
}

/** Réassigne manuellement à un autre commercial */
export function useUpdateAssignation() {
  const queryClient = useQueryClient();
  const updateFn = useServerFn(updateAssignationFn);

  return useMutation({
    mutationFn: async (input: {
      demande_id: string;
      user_id?: string | null;
      user_name: string;
      user_email: string;
    }) => {
      return updateFn({ data: input });
    },
    onSuccess: (saved) => {
      queryClient.setQueryData<Record<string, DemandeAssignation>>(assignationsKey, (prev) => ({
        ...prev,
        [saved.demande_id]: saved,
      }));
      toast.success(`Demande réassignée à ${saved.user_name}`);
    },
onError: (err: Error) => {
      toast.error(err?.message ?? "Erreur lors de la réassignation");
    },
  });
}
