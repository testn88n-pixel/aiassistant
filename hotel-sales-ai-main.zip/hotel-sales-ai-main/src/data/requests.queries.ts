import { queryOptions, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { updateRegistrePricesFn, updateRegistreEmailsCopieFn } from "@/lib/registre.functions";

import { notifyN8nDecision } from "@/lib/n8n.functions";
import { listTeamUsersFn } from "@/lib/assignations.functions";

export function useUpdateEmailsCopie() {
  const queryClient = useQueryClient();
  const updateFn = useServerFn(updateRegistreEmailsCopieFn);

  return useMutation({
    mutationFn: async ({ id, emails_copie }: { id: string; emails_copie: string }) => {
      return updateFn({ data: { id, emails_copie } });
    },
    onSuccess: (updated) => {
      if (updated) {
        queryClient.setQueryData(requestKeys.detail(updated.id), updated);
      }
      toast.success("Copies enregistrées");
    },
    onError: () => {
      toast.error("Impossible d'enregistrer les copies");
    },
  });
}

export function useTeamUsers() {
  return useQuery({
    queryKey: ["team-users"],
    queryFn: () => listTeamUsersFn(),
  });
}

import { requestsRepository } from "./requests-repository";
import { ACTION_REQUIRED_STATUSES, CLOSED_STATUSES, type FbPlanningItem, type NightPrice, type RequestStatus, type SalesRequest } from "./types";

export const isWaitingClient = (r: SalesRequest) => r.statut === "Attente retour client";

export const requestKeys = {
  all: ["requests"] as const,
  detail: (id: string) => ["requests", id] as const,
};

function getSelectedHotelCode(): string {
  if (typeof window === "undefined") return "";
  try {
    const stored = localStorage.getItem("okkosmart_hotel");
    if (!stored) return "";
    const hotel = JSON.parse(stored) as { code?: unknown };
    return typeof hotel.code === "string" ? hotel.code : "";
  } catch {
    return "";
  }
}

export const requestsQueryOptions = queryOptions({
  queryKey: requestKeys.all,
  queryFn: () => {
    const hotelCode = getSelectedHotelCode();
    if (!hotelCode) return [];
    return requestsRepository.list(hotelCode);
  },
  staleTime: 30_000,
});

export const requestQueryOptions = (id: string) =>
  queryOptions({
    queryKey: requestKeys.detail(id),
    queryFn: () => requestsRepository.getById(id),
    staleTime: 30_000,
  });


/* ---------------------------- selectors ---------------------------- */
export const isActive = (r: SalesRequest) => !CLOSED_STATUSES.includes(r.statut);
export const isAccepted = (r: SalesRequest) => r.statut === "Acceptée";
export const isRefused = (r: SalesRequest) => r.statut === "Refusée";
export const isFollowUpDue = (r: SalesRequest) => {
  if (r.statut !== "Acceptée" || !r.date_action || r.repondu) return false;
  const actionTime = new Date(r.date_action).getTime();
  if (Number.isNaN(actionTime)) return false;
  const sevenDaysMs = 7 * 24 * 60 * 60 * 1000;
  return Date.now() - actionTime >= sevenDaysMs;
};
export const needsAction = (r: SalesRequest) => ACTION_REQUIRED_STATUSES.includes(r.statut);
export const byMostRecentEmail = (a: SalesRequest, b: SalesRequest) =>
  (b.date_email ?? "").localeCompare(a.date_email ?? "");
export const byMostRecentAction = (a: SalesRequest, b: SalesRequest) =>
  (b.date_action ?? "").localeCompare(a.date_action ?? "");

export function useSavePrices() {
  const queryClient = useQueryClient();
  const updatePrices = useServerFn(updateRegistrePricesFn);

  return useMutation({
    mutationFn: async (input: {
      id: string;
      tarif_recommande?: string;
      chambres?: number;
      pax?: number;
      seminaire_jours?: string;
      total_seminaire?: number;
      tarifs_par_nuit?: NightPrice[];
      total_hebergement?: number;
      fb_planning?: FbPlanningItem[];
      total_fb?: number;
      total_devis?: number;
    }) => updatePrices({ data: input }),
    onSuccess: (updated) => {
      if (updated) {
        queryClient.setQueryData(requestKeys.detail(updated.id), updated);
        queryClient.invalidateQueries({ queryKey: requestKeys.all });
      }
      toast.success("Prix enregistrés avec succès");
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : "Erreur lors de l'enregistrement des prix"),
  });
}

export function useUpdateInitialStatus() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, statut }: { id: string; statut: RequestStatus }) =>
      requestsRepository.updateStatus({
        id,
        statut,
        event: { action: "Statut mis à jour", detail: `Ouverture par le commercial (${statut})` },
      }),
    onSuccess: (updated) => {
      if (updated) {
        queryClient.setQueryData(requestKeys.detail(updated.id), updated);
        queryClient.invalidateQueries({ queryKey: requestKeys.all });
      }
    },
  });
}

export function useRequestCounts() {
  return useQuery({
    ...requestsQueryOptions,
    select: (requests) => ({
      active: requests.filter(isActive).length,
      waitingClient: requests.filter(isWaitingClient).length,
      accepted: requests.filter(isAccepted).length,
      refused: requests.filter(isRefused).length,
      needsAction: requests.filter(needsAction).length,
      followUp: requests.filter(isFollowUpDue).length,
    }),
  });
}

export function useRefreshRequests() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => queryClient.invalidateQueries({ queryKey: requestKeys.all }),
    onSuccess: () => toast.success("Données actualisées"),
    onError: () => toast.error("Impossible d'actualiser les données"),
  });
}

export function useDecideRequest() {
  const queryClient = useQueryClient();
  const notify = useServerFn(notifyN8nDecision);

  return useMutation({
    mutationFn: async ({
      id,
      decision,
      webhook,
    }: {
      id: string;
      decision: "accept" | "refuse";
      webhook?: Record<string, unknown>;
    }) => {
      const statut: RequestStatus = decision === "accept" ? "Acceptée" : "Refusée";
      const updated = await requestsRepository.updateStatus({
        id,
        statut,
        event:
          decision === "accept"
            ? { action: "Demande acceptée", detail: "Validée par le service commercial" }
            : { action: "Demande refusée", detail: "Bloquée par le service commercial" },
      });

      let emailSent = false;
      let emailError: string | undefined;
      let n8nAction: string | undefined;

      if (webhook) {
        try {
          const result = await notify({ data: { decision, body: webhook } });
          emailSent = result.ok;
          n8nAction = result.action;
          if (!result.ok) emailError = "Réponse inattendue du service d'envoi.";
        } catch (error) {
          emailError = error instanceof Error ? error.message : "Erreur inconnue";
        }
      }

      return { updated, emailSent, emailError, n8nAction };
    },
    onSuccess: async ({ updated, emailSent, emailError, n8nAction }) => {
      queryClient.setQueryData(requestKeys.detail(updated.id), updated);
      await queryClient.invalidateQueries({ queryKey: requestKeys.all });

      const label = updated.statut === "Acceptée" ? "acceptée" : "refusée";
      if (emailError) {
        toast.warning(`Demande ${updated.id} ${label}`, {
          description: `L'email au client n'a pas pu être envoyé : ${emailError}`,
        });
        return;
      }

      if (n8nAction === "validee_sans_devis") {
        toast.success("Mail envoyé sans devis");
      } else if (n8nAction === "validee") {
        toast.success("Mail envoyé avec le devis");
      } else {
        toast.success(`Demande ${updated.id} ${label}`, {
          description: emailSent ? "Email envoyé au client." : undefined,
        });
      }
    },
    onError: () => toast.error("La mise à jour du statut a échoué"),
  });
}
