import type { SalesRequest } from "./types";

const HOTEL = "Hôtel Le Grand Pavillon Paris";
const HOTEL_EMAIL = "groupes@grandpavillon-paris.com";

export const MOCK_REQUESTS: SalesRequest[] = [
  {
    id: "REQ-001",
    date_traitement: "2026-09-21T09:42:00",
    societe: "L'Oréal France",
    nom_groupe: "Séminaire Marketing Luxe 2026",
    contact: "Claire Fontaine",
    email: "claire.fontaine@loreal.com",
    date_email: "2026-09-21T09:38:00",
    subject: "Demande de devis – séminaire 12-14 novembre 2026 (80 personnes)",
    statut: "RM en attente",

    hotel: HOTEL,
    date_debut: "2026-11-12",
    date_fin: "2026-11-14",
    nombre_nuits: 2,
    pax: 80,
    chambres: 40,
    categorie: "Supérieure",
    type_chambre: "Double",
    chambres_disponibles: 52,
    statut_hebergement: "Disponible",

    seminaire_demande: "Oui",
    seminaire_date: "2026-11-13",
    seminaire_heure_debut: "09:00",
    seminaire_heure_fin: "17:30",
    seminaire_pax: 80,
    seminaire_salle_demandee: "Salle plénière",
    seminaire_salle_proposee: "Salon Haussmann",
    seminaire_capacite: 120,
    seminaire_disponible: "Oui",
    seminaire_statut: "Disponible",
    seminaire_salle_prix: 900,
    seminaire_salle_unite: "par jour",
    seminaire_disposition: "Théâtre",

    pause_matin_demande: "Oui",
    pause_matin_disponible: "Oui",
    pause_matin_prix: 12,
    pause_matin_unite: "par personne",
    pause_apres_midi_demande: "Oui",
    pause_apres_midi_disponible: "Oui",
    pause_apres_midi_prix: 12,
    pause_apres_midi_unite: "par personne",

    cafe_d_accueil_detecte: "Oui",
    cafe_d_accueil_disponible: "Oui",
    cafe_d_accueil_prix: 6,
    cafe_d_accueil_unite: "par personne",

    fb_demande: "Oui",
    fb_pax: 80,
    fb_localisation: "Restaurant principal",
    dejeuner_demande: "Oui",
    dejeuner_disponible: "Oui",
    diner_demande: "Non",
    fb_statut: "Disponible",
    fb_cocktail_prix: 25,
    fb_cocktail_unite: "par personne",
    fb_dejeuner_prix: 45,
    fb_dejeuner_unite: "par personne",

    statut_completude: "Complète",

tarif_recommande: "185",
    devise: "EUR",
    unite_tarif: "par chambre et par nuit",
    origine_tarif: "Yield / RM",
    methode_tarif: "Grille groupe saison haute, ajustement volume 40 chambres",
    raison_tarif: "Période de forte demande (novembre), taux d'occupation prévisionnel 78 %.",
    rm_requis: "Oui",
    demande_rm: "Validation du tarif 185 EUR pour 40 chambres doubles sur 2 nuits (12-14 nov. 2026).",

    numero_devis: "DEV-2026-0341",
    date_creation_devis: "2026-09-21T09:47:00",
    statut_devis: "Généré",
    total_devis: 22450,
    recap_devis: [
      { libelle: "Chambres doubles supérieures (40 × 2 nuits)", categorie: "Hébergement", quantite: 80, unite: "nuitée", prix_unitaire: 185, total: 14800 },
      { libelle: "Salon Haussmann – disposition théâtre", categorie: "Séminaire", quantite: 1, unite: "jour", prix_unitaire: 900, total: 900 },
      { libelle: "Café d'accueil", categorie: "Séminaire", quantite: 80, unite: "personne", prix_unitaire: 6, total: 480 },
      { libelle: "Pause matin", categorie: "Pauses", quantite: 80, unite: "personne", prix_unitaire: 12, total: 960 },
      { libelle: "Pause après-midi", categorie: "Pauses", quantite: 80, unite: "personne", prix_unitaire: 12, total: 960 },
      { libelle: "Déjeuner buffet – restaurant principal", categorie: "F&B", quantite: 80, unite: "personne", prix_unitaire: 45, total: 3600 },
      { libelle: "Cocktail de bienvenue", categorie: "F&B", quantite: 30, unite: "personne", prix_unitaire: 25, total: 750 },
    ],

    email_original: `Bonjour,

Dans le cadre de notre séminaire annuel de la division Luxe, nous recherchons un hôtel à Paris pour accueillir 80 collaborateurs du 12 au 14 novembre 2026.

Nos besoins :
- 40 chambres doubles pour 2 nuits (arrivée le 12, départ le 14)
- Une salle plénière le 13 novembre de 9h à 17h30, disposition théâtre
- Café d'accueil, pause le matin et l'après-midi
- Déjeuner le 13 novembre pour l'ensemble des participants
- Un cocktail de bienvenue pour une trentaine de personnes le soir de l'arrivée

Pourriez-vous nous transmettre une proposition tarifaire ?

Bien cordialement,
Claire Fontaine
Responsable Événements – L'Oréal France`,

    dates_detectees: "12 → 14 novembre 2026",
    nuits_detectees: "2 nuits",
    chambres_detectees: "40 chambres",
    pax_detectes: "80 participants",
    type_chambre_detecte: "Double",
    seminaire_detecte: "Salle plénière le 13 novembre, disposition théâtre",
    horaires_detectes: "09:00 – 17:30",
    dejeuner_detecte: "Déjeuner le 13 novembre pour 80 personnes",
    pauses_detectees: "Café d'accueil, pause matin, pause après-midi",

    email_reponse: `Bonjour Madame Fontaine,

Nous vous remercions pour votre demande concernant le séminaire de la division Luxe du 12 au 14 novembre 2026.

Nous avons le plaisir de vous confirmer la disponibilité de 40 chambres doubles supérieures pour 2 nuits, ainsi que du Salon Haussmann en disposition théâtre pour votre journée plénière du 13 novembre.

Vous trouverez ci-joint notre proposition détaillée (devis DEV-2026-0341) d'un montant total de 22 450 EUR, comprenant l'hébergement, la salle, le café d'accueil, les pauses, le déjeuner et le cocktail de bienvenue.

Nous restons à votre disposition pour toute précision ou pour organiser une visite de l'hôtel.

Bien cordialement,
Service Commercial Groupes
${HOTEL}`,

    historique: [
      { date: "2026-09-21T09:38:00", action: "Demande reçue", detail: "Email de claire.fontaine@loreal.com" },
      { date: "2026-09-21T09:40:00", action: "Analyse IA", detail: "Extraction des dates, chambres, séminaire et F&B" },
      { date: "2026-09-21T09:41:00", action: "Informations détectées", detail: "Demande complète – aucune information manquante" },
      { date: "2026-09-21T09:44:00", action: "Pricing calculé", detail: "Tarif recommandé 185 EUR (Yield / RM)" },
      { date: "2026-09-21T09:45:00", action: "Demande RM envoyée", detail: "Validation tarif 40 chambres × 2 nuits" },
      { date: "2026-09-21T09:47:00", action: "Devis généré", detail: "DEV-2026-0341 – 22 450 EUR" },
      { date: "2026-09-21T09:48:00", action: "Réponse préparée", detail: "Brouillon de réponse client disponible" },
    ],
  },

  {
    id: "REQ-002",
    date_traitement: "2026-09-22T11:05:00",
    societe: "Deloitte France",
    nom_groupe: "Convention Audit & Assurance",
    contact: "Thomas Renard",
    email: "trenard@deloitte.fr",
    date_email: "2026-09-22T10:58:00",
    subject: "Convention interne 3-5 décembre 2026 – 50 participants",
    statut: "RM en attente",

    hotel: HOTEL,
    date_debut: "2026-12-03",
    date_fin: "2026-12-05",
    nombre_nuits: 2,
    pax: 50,
    chambres: 25,
    categorie: "Deluxe",
    type_chambre: "Double",
    chambres_disponibles: 31,
    statut_hebergement: "Disponible",

    seminaire_demande: "Oui",
    seminaire_date: "2026-12-04",
    seminaire_heure_debut: "08:30",
    seminaire_heure_fin: "18:00",
    seminaire_pax: 50,
    seminaire_salle_demandee: "Salle de réunion 50 personnes",
    seminaire_salle_proposee: "Salon Opéra",
    seminaire_capacite: 70,
    seminaire_disponible: "Oui",
    seminaire_statut: "Disponible",
    seminaire_salle_prix: 900,
    seminaire_salle_unite: "par jour",
    seminaire_disposition: "En U",

    pause_matin_demande: "Oui",
    pause_matin_disponible: "Oui",
    pause_matin_prix: 12,
    pause_matin_unite: "par personne",
    pause_apres_midi_demande: "Oui",
    pause_apres_midi_disponible: "Oui",
    pause_apres_midi_prix: 12,
    pause_apres_midi_unite: "par personne",

    cafe_d_accueil_detecte: "Oui",
    cafe_d_accueil_disponible: "Oui",
    cafe_d_accueil_prix: 15,
    cafe_d_accueil_unite: "par personne",

    fb_demande: "Oui",
    fb_pax: 50,
    fb_localisation: "Restaurant principal",
    dejeuner_demande: "Oui",
    dejeuner_disponible: "Oui",
    diner_demande: "Non",
    fb_statut: "Disponible",
    fb_cocktail_prix: 25,
    fb_cocktail_unite: "par personne",
    fb_dejeuner_prix: 45,
    fb_dejeuner_unite: "par personne",

    statut_completude: "Complète",

tarif_recommande: "210",
    devise: "EUR",
    unite_tarif: "par chambre et par nuit",
    origine_tarif: "Yield / RM",
    methode_tarif: "Grille groupe décembre, catégorie Deluxe",
    raison_tarif: "Semaine de forte activité corporate, disponibilité limitée en catégorie Deluxe.",
    rm_requis: "Oui",
    demande_rm: "Validation du tarif 210 EUR pour 25 chambres Deluxe sur 2 nuits (3-5 déc. 2026).",

    numero_devis: "DEV-2026-0347",
    date_creation_devis: "2026-09-22T11:09:00",
    statut_devis: "Généré",
    total_devis: 16850,
    recap_devis: [
      { libelle: "Chambres doubles Deluxe (25 × 2 nuits)", categorie: "Hébergement", quantite: 50, unite: "nuitée", prix_unitaire: 210, total: 10500 },
      { libelle: "Salon Opéra – disposition en U", categorie: "Séminaire", quantite: 1, unite: "jour", prix_unitaire: 900, total: 900 },
      { libelle: "Café d'accueil", categorie: "Séminaire", quantite: 50, unite: "personne", prix_unitaire: 15, total: 750 },
      { libelle: "Pause matin", categorie: "Pauses", quantite: 50, unite: "personne", prix_unitaire: 12, total: 600 },
      { libelle: "Pause après-midi", categorie: "Pauses", quantite: 50, unite: "personne", prix_unitaire: 12, total: 600 },
      { libelle: "Déjeuner – restaurant principal", categorie: "F&B", quantite: 50, unite: "personne", prix_unitaire: 45, total: 2250 },
      { libelle: "Cocktail de clôture", categorie: "F&B", quantite: 50, unite: "personne", prix_unitaire: 25, total: 1250 },
    ],

    email_original: `Bonjour,

Nous organisons une convention interne pour 50 collaborateurs du 3 au 5 décembre 2026 et souhaitons recevoir une proposition.

Détail :
- 25 chambres doubles, 2 nuits
- 1 salle de réunion pour 50 personnes le 4 décembre, de 8h30 à 18h, en U
- Café d'accueil et deux pauses
- Déjeuner le 4 décembre
- Cocktail de clôture le 4 décembre en fin de journée

Merci de nous indiquer vos disponibilités et conditions.

Cordialement,
Thomas Renard
Deloitte France – Office Management`,

    dates_detectees: "3 → 5 décembre 2026",
    nuits_detectees: "2 nuits",
    chambres_detectees: "25 chambres",
    pax_detectes: "50 participants",
    type_chambre_detecte: "Double",
    seminaire_detecte: "Salle de réunion le 4 décembre, disposition en U",
    horaires_detectes: "08:30 – 18:00",
    dejeuner_detecte: "Déjeuner le 4 décembre pour 50 personnes",
    pauses_detectees: "Café d'accueil, pause matin, pause après-midi",

    email_reponse: `Bonjour Monsieur Renard,

Nous vous remercions pour votre demande concernant votre convention du 3 au 5 décembre 2026.

Nous sommes en mesure de vous proposer 25 chambres doubles Deluxe pour 2 nuits ainsi que le Salon Opéra en disposition en U pour votre journée du 4 décembre.

Vous trouverez ci-joint notre devis DEV-2026-0347 d'un montant total de 16 850 EUR.

Nous restons à votre entière disposition.

Bien cordialement,
Service Commercial Groupes
${HOTEL}`,

    historique: [
      { date: "2026-09-22T10:58:00", action: "Demande reçue", detail: "Email de trenard@deloitte.fr" },
      { date: "2026-09-22T11:01:00", action: "Analyse IA", detail: "Extraction des besoins hébergement, séminaire et F&B" },
      { date: "2026-09-22T11:02:00", action: "Informations détectées", detail: "Demande complète" },
      { date: "2026-09-22T11:06:00", action: "Pricing calculé", detail: "Tarif recommandé 210 EUR (Yield / RM)" },
      { date: "2026-09-22T11:07:00", action: "Demande RM envoyée", detail: "Validation tarif 25 chambres Deluxe × 2 nuits" },
      { date: "2026-09-22T11:09:00", action: "Devis généré", detail: "DEV-2026-0347 – 16 850 EUR" },
      { date: "2026-09-22T11:10:00", action: "Réponse préparée" },
    ],
  },

  {
    id: "REQ-003",
    date_traitement: "2026-09-22T15:20:00",
    societe: "Airbus France",
    nom_groupe: "Réunion Supply Chain",
    contact: "Marc Delorme",
    email: "marc.delorme@airbus.com",
    date_email: "2026-09-22T15:12:00",
    subject: "Journée de travail le 21 janvier 2027 – environ 35 personnes",
    statut: "Informations manquantes",

    hotel: HOTEL,
    date_debut: "2027-01-21",
    pax: 35,
    chambres: 18,
    type_chambre: "Double",
    statut_hebergement: "Informations manquantes",
    raison_hebergement: "Date de départ et nombre exact de chambres non précisés.",

    seminaire_demande: "Oui",
    seminaire_date: "2027-01-21",
    seminaire_pax: 35,
    seminaire_salle_demandee: "Salle de travail",
    seminaire_statut: "À confirmer",
    seminaire_raison: "Horaires du séminaire non communiqués.",

    fb_demande: "Oui",
    fb_pax: 35,
    fb_statut: "Informations manquantes",
    fb_raison: "Déjeuner ou dîner à confirmer.",

    statut_completude: "Incomplète",
    champs_manquants: ["date_fin", "nombre_nuits", "chambres", "seminaire_heure_debut", "seminaire_heure_fin", "dejeuner_demande", "diner_demande"],
    question_clarification:
      "Pourriez-vous nous préciser la date de départ, le nombre exact de chambres souhaité, les horaires de votre journée de travail ainsi que la formule de restauration envisagée (déjeuner et/ou dîner) ?",

    devise: "EUR",
    rm_requis: "Non",

    numero_devis: "DEV-2026-0352",
    date_creation_devis: "2026-09-22T15:24:00",
    statut_devis: "En attente d'informations",
    total_devis: 0,
    recap_devis: [],

    email_original: `Bonjour,

Nous souhaiterions organiser une journée de travail le 21 janvier 2027 pour environ 35 personnes de notre équipe Supply Chain.

Il nous faudrait une salle de travail et probablement une vingtaine de chambres (18 environ, en double), à confirmer selon les participants qui viendront de Toulouse.

Nous aurons également besoin de restauration sur place.

Pouvez-vous nous dire si c'est envisageable ?

Merci,
Marc Delorme
Airbus France`,

    dates_detectees: "21 janvier 2027 (date de départ non précisée)",
    chambres_detectees: "≈ 18 chambres (à confirmer)",
    pax_detectes: "≈ 35 participants",
    type_chambre_detecte: "Double",
    seminaire_detecte: "Salle de travail le 21 janvier",
    dejeuner_detecte: "Restauration mentionnée sans précision (déjeuner / dîner)",
    informations_manquantes: [
      "Date de départ manquante",
      "Nombre exact de chambres manquant",
      "Horaire du séminaire manquant",
      "Déjeuner ou dîner à confirmer",
    ],

    email_reponse: `Bonjour Monsieur Delorme,

Nous vous remercions pour votre demande concernant votre journée de travail du 21 janvier 2027.

Afin de vous adresser une proposition adaptée, pourriez-vous nous préciser :
- la date de départ du groupe et le nombre de nuits souhaité,
- le nombre exact de chambres,
- les horaires de votre journée de travail,
- la formule de restauration envisagée (déjeuner et/ou dîner).

Dès réception de ces éléments, nous vous transmettrons une proposition détaillée.

Bien cordialement,
Service Commercial Groupes
${HOTEL}`,

    historique: [
      { date: "2026-09-22T15:12:00", action: "Demande reçue", detail: "Email de marc.delorme@airbus.com" },
      { date: "2026-09-22T15:15:00", action: "Analyse IA", detail: "Extraction partielle des besoins" },
      { date: "2026-09-22T15:17:00", action: "Informations détectées", detail: "4 informations manquantes identifiées" },
      { date: "2026-09-22T15:24:00", action: "Devis généré", detail: "DEV-2026-0352 – en attente d'informations" },
      { date: "2026-09-22T15:25:00", action: "Réponse préparée", detail: "Question de clarification proposée" },
    ],
  },

  {
    id: "REQ-004",
    date_traitement: "2026-09-23T08:50:00",
    societe: "Orange Business",
    nom_groupe: "Kick-off Commercial 2027",
    contact: "Sophie Marchand",
    email: "sophie.marchand@orange.com",
    date_email: "2026-09-23T08:41:00",
    subject: "Kick-off commercial 15-17 février 2027 – 60 personnes",
    statut: "Informations manquantes",

    hotel: HOTEL,
    date_debut: "2027-02-15",
    date_fin: "2027-02-17",
    nombre_nuits: 2,
    pax: 60,
    chambres: 30,
    type_chambre: "Double",
    chambres_disponibles: 44,
    statut_hebergement: "À confirmer",
    raison_hebergement: "Nombre exact de chambres à confirmer par le client.",

    seminaire_demande: "Oui",
    seminaire_date: "2027-02-16",
    seminaire_heure_debut: "09:00",
    seminaire_heure_fin: "17:00",
    seminaire_pax: 60,
    seminaire_salle_demandee: "Salle plénière + 2 sous-commissions",
    seminaire_salle_proposee: "Salon Haussmann + Salons Rivoli 1 & 2",
    seminaire_capacite: 120,
    seminaire_disponible: "Oui",
    seminaire_statut: "Disponible",

    fb_demande: "Oui",
    fb_pax: 60,
    fb_statut: "Informations manquantes",
    fb_raison: "Formule de restauration non précisée (déjeuner, dîner, cocktail).",

    statut_completude: "Incomplète",
    champs_manquants: ["chambres", "dejeuner_demande", "diner_demande", "pause_matin_demande", "pause_apres_midi_demande"],
    question_clarification:
      "Pourriez-vous nous confirmer le nombre exact de chambres ainsi que vos souhaits en matière de restauration (déjeuners, dîner, cocktail, pauses) ?",

    devise: "EUR",
    rm_requis: "Non",

    numero_devis: "DEV-2026-0355",
    date_creation_devis: "2026-09-23T08:56:00",
    statut_devis: "En attente d'informations",
    total_devis: 0,
    recap_devis: [],

    email_original: `Bonjour,

Orange Business organise son kick-off commercial du 15 au 17 février 2027 et nous cherchons un hôtel pour 60 personnes.

Nous aurions besoin d'environ 30 chambres doubles (le nombre exact reste à confirmer), d'une salle plénière le 16 février de 9h à 17h et de deux salles de sous-commission.

Concernant la restauration, nous reviendrons vers vous avec plus de détails, mais merci de nous indiquer vos possibilités.

Bien à vous,
Sophie Marchand
Orange Business – Direction Commerciale`,

    dates_detectees: "15 → 17 février 2027",
    nuits_detectees: "2 nuits",
    chambres_detectees: "≈ 30 chambres (nombre exact à confirmer)",
    pax_detectes: "60 participants",
    type_chambre_detecte: "Double",
    seminaire_detecte: "Plénière + 2 sous-commissions le 16 février",
    horaires_detectes: "09:00 – 17:00",
    dejeuner_detecte: "Restauration à préciser",
    informations_manquantes: [
      "Nombre exact de chambres à confirmer",
      "Déjeuner ou dîner à confirmer",
      "Pauses à confirmer",
    ],

    email_reponse: `Bonjour Madame Marchand,

Nous vous remercions pour votre demande concernant votre kick-off commercial du 15 au 17 février 2027.

Nous pouvons d'ores et déjà vous confirmer la disponibilité du Salon Haussmann ainsi que de deux salons de sous-commission pour le 16 février.

Afin de finaliser notre proposition, pourriez-vous nous confirmer le nombre exact de chambres ainsi que vos souhaits en matière de restauration (déjeuners, dîner, cocktail, pauses) ?

Bien cordialement,
Service Commercial Groupes
${HOTEL}`,

    historique: [
      { date: "2026-09-23T08:41:00", action: "Demande reçue", detail: "Email de sophie.marchand@orange.com" },
      { date: "2026-09-23T08:45:00", action: "Analyse IA", detail: "Extraction des besoins hébergement et séminaire" },
      { date: "2026-09-23T08:47:00", action: "Informations détectées", detail: "Restauration et nombre de chambres à confirmer" },
      { date: "2026-09-23T08:56:00", action: "Devis généré", detail: "DEV-2026-0355 – en attente d'informations" },
      { date: "2026-09-23T08:57:00", action: "Réponse préparée", detail: "Question de clarification proposée" },
    ],
  },

  {
    id: "REQ-005",
    date_traitement: "2026-09-23T14:12:00",
    societe: "Microsoft France",
    nom_groupe: "Partner Summit 2027",
    contact: "Julien Lefebvre",
    email: "julien.lefebvre@microsoft.com",
    date_email: "2026-09-23T14:05:00",
    subject: "Partner Summit 18-20 mars 2027 – 80 participants",
    statut: "RM en attente",

    hotel: HOTEL,
    date_debut: "2027-03-18",
    date_fin: "2027-03-20",
    nombre_nuits: 2,
    pax: 80,
    chambres: 40,
    categorie: "Supérieure",
    type_chambre: "Double",
    chambres_disponibles: 58,
    statut_hebergement: "Disponible",

    seminaire_demande: "Oui",
    seminaire_date: "2027-03-19",
    seminaire_heure_debut: "09:00",
    seminaire_heure_fin: "18:00",
    seminaire_pax: 80,
    seminaire_salle_demandee: "Salle plénière 80 personnes",
    seminaire_salle_proposee: "Salon Haussmann",
    seminaire_capacite: 120,
    seminaire_disponible: "Oui",
    seminaire_statut: "Disponible",
    seminaire_salle_prix: 900,
    seminaire_salle_unite: "par jour",
    seminaire_disposition: "Théâtre",

    pause_matin_demande: "Oui",
    pause_matin_disponible: "Oui",
    pause_matin_prix: 12,
    pause_matin_unite: "par personne",
    pause_apres_midi_demande: "Oui",
    pause_apres_midi_disponible: "Oui",
    pause_apres_midi_prix: 12,
    pause_apres_midi_unite: "par personne",

    cafe_d_accueil_detecte: "Oui",
    cafe_d_accueil_disponible: "Oui",
    cafe_d_accueil_prix: 10,
    cafe_d_accueil_unite: "par personne",

    fb_demande: "Oui",
    fb_pax: 80,
    fb_localisation: "Restaurant principal",
    dejeuner_demande: "Oui",
    dejeuner_disponible: "Oui",
    diner_demande: "Oui",
    diner_disponible: "Oui",
    fb_statut: "Disponible",
    fb_cocktail_prix: 25,
    fb_cocktail_unite: "par personne",
    fb_dejeuner_prix: 45,
    fb_dejeuner_unite: "par personne",
    fb_diner_prix: 55,
    fb_diner_unite: "par personne",
    fb_dejeuner_assis_prix: 65,
    fb_dejeuner_assis_unite: "par personne",
    fb_diner_assis_prix: 75,
    fb_diner_assis_unite: "par personne",

    statut_completude: "Complète",

tarif_recommande: "185",
    devise: "EUR",
    unite_tarif: "par chambre et par nuit",
    origine_tarif: "Yield / RM",
    methode_tarif: "Grille groupe mars, ajustement volume 40 chambres",
    raison_tarif: "Occupation prévisionnelle modérée en mars, tarif groupe standard applicable.",
    rm_requis: "Oui",
    demande_rm: "Validation du tarif 185 EUR pour 40 chambres doubles sur 2 nuits (18-20 mars 2027).",

    numero_devis: "DEV-2026-0358",
    date_creation_devis: "2026-09-23T14:18:00",
    statut_devis: "Généré",
    total_devis: 28420,
    recap_devis: [
      { libelle: "Chambres doubles supérieures (40 × 2 nuits)", categorie: "Hébergement", quantite: 80, unite: "nuitée", prix_unitaire: 185, total: 14800 },
      { libelle: "Salon Haussmann – disposition théâtre", categorie: "Séminaire", quantite: 1, unite: "jour", prix_unitaire: 900, total: 900 },
      { libelle: "Café d'accueil", categorie: "Séminaire", quantite: 80, unite: "personne", prix_unitaire: 10, total: 800 },
      { libelle: "Pause matin", categorie: "Pauses", quantite: 80, unite: "personne", prix_unitaire: 12, total: 960 },
      { libelle: "Pause après-midi", categorie: "Pauses", quantite: 80, unite: "personne", prix_unitaire: 12, total: 960 },
      { libelle: "Cocktail de bienvenue", categorie: "F&B", quantite: 80, unite: "personne", prix_unitaire: 25, total: 2000 },
      { libelle: "Déjeuner – restaurant principal", categorie: "F&B", quantite: 80, unite: "personne", prix_unitaire: 45, total: 3600 },
      { libelle: "Dîner – restaurant principal", categorie: "F&B", quantite: 80, unite: "personne", prix_unitaire: 55, total: 4400 },
    ],

    email_original: `Bonjour,

Microsoft France organise son Partner Summit du 18 au 20 mars 2027 à Paris pour 80 partenaires.

Nous recherchons :
- 40 chambres doubles pour 2 nuits
- Une salle plénière le 19 mars de 9h à 18h, en disposition théâtre
- Café d'accueil et pauses matin / après-midi
- Cocktail de bienvenue le 18 au soir
- Déjeuner et dîner le 19 mars au restaurant de l'hôtel

Merci de nous adresser une proposition complète.

Cordialement,
Julien Lefebvre
Partner Marketing – Microsoft France`,

    dates_detectees: "18 → 20 mars 2027",
    nuits_detectees: "2 nuits",
    chambres_detectees: "40 chambres",
    pax_detectes: "80 participants",
    type_chambre_detecte: "Double",
    seminaire_detecte: "Salle plénière le 19 mars, disposition théâtre",
    horaires_detectes: "09:00 – 18:00",
    dejeuner_detecte: "Déjeuner et dîner le 19 mars pour 80 personnes",
    pauses_detectees: "Café d'accueil, pause matin, pause après-midi",

    email_reponse: `Bonjour Monsieur Lefebvre,

Nous vous remercions pour votre demande concernant le Partner Summit du 18 au 20 mars 2027.

Nous avons le plaisir de vous confirmer la disponibilité de 40 chambres doubles supérieures pour 2 nuits, du Salon Haussmann en disposition théâtre le 19 mars, ainsi que de notre restaurant principal pour le cocktail, le déjeuner et le dîner.

Vous trouverez ci-joint notre devis DEV-2026-0358 d'un montant total de 28 420 EUR.

Nous restons à votre disposition pour toute question.

Bien cordialement,
Service Commercial Groupes
${HOTEL}`,

    historique: [
      { date: "2026-09-23T14:05:00", action: "Demande reçue", detail: "Email de julien.lefebvre@microsoft.com" },
      { date: "2026-09-23T14:08:00", action: "Analyse IA", detail: "Extraction complète des besoins" },
      { date: "2026-09-23T14:09:00", action: "Informations détectées", detail: "Demande complète" },
      { date: "2026-09-23T14:14:00", action: "Pricing calculé", detail: "Tarif recommandé 185 EUR (Yield / RM)" },
      { date: "2026-09-23T14:15:00", action: "Demande RM envoyée", detail: "Validation tarif 40 chambres × 2 nuits" },
      { date: "2026-09-23T14:18:00", action: "Devis généré", detail: "DEV-2026-0358 – 28 420 EUR" },
      { date: "2026-09-23T14:19:00", action: "Réponse préparée" },
    ],
  },

  {
    id: "REQ-006",
    date_traitement: "2026-09-24T10:02:00",
    societe: "Airbus France",
    nom_groupe: "Séminaire Direction Programmes",
    contact: "Isabelle Garnier",
    email: "isabelle.garnier@airbus.com",
    date_email: "2026-09-24T09:55:00",
    subject: "Séminaire direction 7-10 avril 2027 – 60 personnes",
    statut: "Prête à valider",

    hotel: HOTEL,
    date_debut: "2027-04-07",
    date_fin: "2027-04-10",
    nombre_nuits: 3,
    pax: 60,
    chambres: 30,
    categorie: "Deluxe",
    type_chambre: "Double",
    chambres_disponibles: 36,
    statut_hebergement: "Disponible",

    seminaire_demande: "Oui",
    seminaire_date: "2027-04-08",
    seminaire_heure_debut: "08:30",
    seminaire_heure_fin: "18:30",
    seminaire_pax: 60,
    seminaire_salle_demandee: "Salle Concorde",
    seminaire_salle_proposee: "Salle Concorde",
    seminaire_capacite: 90,
    seminaire_disponible: "Oui",
    seminaire_statut: "Disponible",
    seminaire_salle_prix: 1200,
    seminaire_salle_unite: "par jour",
    seminaire_disposition: "Classe",

    pause_matin_demande: "Oui",
    pause_matin_disponible: "Oui",
    pause_matin_prix: 15,
    pause_matin_unite: "par personne",
    pause_apres_midi_demande: "Oui",
    pause_apres_midi_disponible: "Oui",
    pause_apres_midi_prix: 15,
    pause_apres_midi_unite: "par personne",

    cafe_d_accueil_detecte: "Oui",
    cafe_d_accueil_disponible: "Oui",
    cafe_d_accueil_prix: 9,
    cafe_d_accueil_unite: "par personne",

    fb_demande: "Oui",
    fb_pax: 60,
    fb_localisation: "Restaurant panoramique",
    dejeuner_demande: "Oui",
    dejeuner_disponible: "Oui",
    diner_demande: "Oui",
    diner_disponible: "Oui",
    fb_statut: "Disponible",
    fb_cocktail_prix: 30,
    fb_cocktail_unite: "par personne",
    fb_dejeuner_prix: 50,
    fb_dejeuner_unite: "par personne",
    fb_diner_prix: 65,
    fb_diner_unite: "par personne",
    fb_dejeuner_assis_prix: 75,
    fb_dejeuner_assis_unite: "par personne",
    fb_diner_assis_prix: 85,
    fb_diner_assis_unite: "par personne",

    statut_completude: "Complète",

tarif_recommande: "210",
    devise: "EUR",
    unite_tarif: "par chambre et par nuit",
    origine_tarif: "Tarif contractuel",
    methode_tarif: "Accord cadre Airbus 2027 – catégorie Deluxe",
    raison_tarif: "Tarif négocié dans le cadre de l'accord entreprise en vigueur.",
    rm_requis: "Non",

    numero_devis: "DEV-2026-0362",
    date_creation_devis: "2026-09-24T10:08:00",
    statut_devis: "Généré",
    total_devis: 35640,
    recap_devis: [
      { libelle: "Chambres doubles Deluxe (30 × 3 nuits)", categorie: "Hébergement", quantite: 90, unite: "nuitée", prix_unitaire: 210, total: 18900 },
      { libelle: "Salle Concorde – disposition classe", categorie: "Séminaire", quantite: 1, unite: "jour", prix_unitaire: 1200, total: 1200 },
      { libelle: "Café d'accueil", categorie: "Séminaire", quantite: 60, unite: "personne", prix_unitaire: 9, total: 540 },
      { libelle: "Pause matin", categorie: "Pauses", quantite: 60, unite: "personne", prix_unitaire: 15, total: 900 },
      { libelle: "Pause après-midi", categorie: "Pauses", quantite: 60, unite: "personne", prix_unitaire: 15, total: 900 },
      { libelle: "Cocktail de bienvenue – restaurant panoramique", categorie: "F&B", quantite: 60, unite: "personne", prix_unitaire: 30, total: 1800 },
      { libelle: "Déjeuner buffet – restaurant panoramique", categorie: "F&B", quantite: 60, unite: "personne", prix_unitaire: 50, total: 3000 },
      { libelle: "Déjeuner assis – restaurant panoramique", categorie: "F&B", quantite: 60, unite: "personne", prix_unitaire: 75, total: 4500 },
      { libelle: "Dîner – restaurant panoramique", categorie: "F&B", quantite: 60, unite: "personne", prix_unitaire: 65, total: 3900 },
    ],

    email_original: `Bonjour,

Dans le cadre du séminaire annuel de la Direction des Programmes, nous souhaitons réserver votre établissement du 7 au 10 avril 2027 pour 60 personnes.

Besoins :
- 30 chambres doubles Deluxe, 3 nuits
- Salle Concorde le 8 avril de 8h30 à 18h30, disposition classe
- Café d'accueil, pause matin et pause après-midi
- Cocktail de bienvenue le 7 avril au restaurant panoramique
- Déjeuner buffet le 8 avril, déjeuner assis le 9 avril, dîner le 8 avril

Merci de nous confirmer la disponibilité et d'appliquer les conditions de notre accord cadre.

Bien cordialement,
Isabelle Garnier
Airbus France – Direction des Programmes`,

    dates_detectees: "7 → 10 avril 2027",
    nuits_detectees: "3 nuits",
    chambres_detectees: "30 chambres",
    pax_detectes: "60 participants",
    type_chambre_detecte: "Double Deluxe",
    seminaire_detecte: "Salle Concorde le 8 avril, disposition classe",
    horaires_detectes: "08:30 – 18:30",
    dejeuner_detecte: "Déjeuner buffet le 8 avril, déjeuner assis le 9 avril, dîner le 8 avril",
    pauses_detectees: "Café d'accueil, pause matin, pause après-midi",

    email_reponse: `Bonjour Madame Garnier,

Nous vous remercions pour votre demande concernant le séminaire de la Direction des Programmes du 7 au 10 avril 2027.

Nous avons le plaisir de vous confirmer la disponibilité de 30 chambres doubles Deluxe pour 3 nuits, de la Salle Concorde en disposition classe le 8 avril ainsi que de notre restaurant panoramique pour l'ensemble de vos prestations de restauration.

Conformément à votre accord cadre, le tarif contractuel de 210 EUR par chambre et par nuit a été appliqué. Vous trouverez ci-joint notre devis DEV-2026-0362 d'un montant total de 35 640 EUR.

Nous restons à votre disposition.

Bien cordialement,
Service Commercial Groupes
${HOTEL}`,

    historique: [
      { date: "2026-09-24T09:55:00", action: "Demande reçue", detail: "Email de isabelle.garnier@airbus.com" },
      { date: "2026-09-24T09:58:00", action: "Analyse IA", detail: "Extraction complète des besoins" },
      { date: "2026-09-24T09:59:00", action: "Informations détectées", detail: "Demande complète" },
      { date: "2026-09-24T10:04:00", action: "Pricing calculé", detail: "Tarif contractuel 210 EUR – accord cadre Airbus" },
      { date: "2026-09-24T10:08:00", action: "Devis généré", detail: "DEV-2026-0362 – 35 640 EUR" },
      { date: "2026-09-24T10:09:00", action: "Réponse préparée", detail: "Prête pour validation commerciale" },
    ],
  },
];

export const HOTEL_NAME = "GPP";
export const HOTEL_GROUP_EMAIL = HOTEL_EMAIL;
