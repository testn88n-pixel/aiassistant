import { googleSheetsRepository } from "./google-sheets-repository";
import { MOCK_REQUESTS } from "./mock-requests";
import type { HistoryEvent, RequestStatus, SalesRequest } from "./types";

/**
 * Data access contract for requests.
 * The list is always scoped to the selected hotel.
 */
export interface RequestsRepository {
  list(hotelCode: string): Promise<SalesRequest[]>;
  getById(id: string): Promise<SalesRequest | null>;
  updateStatus(input: {
    id: string;
    statut: RequestStatus;
    event: Omit<HistoryEvent, "date">;
  }): Promise<SalesRequest>;
  updateOtherRequests(input: {
    id: string;
    autres_demandes: string;
  }): Promise<SalesRequest>;
}

/* Mock implementation (in-memory, prototype phase) */
const clone = <T>(value: T): T => JSON.parse(JSON.stringify(value)) as T;
const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

let store: SalesRequest[] = clone(MOCK_REQUESTS);

export const mockRequestsRepository: RequestsRepository = {
  async list(hotelCode) {
    await wait(250);
    return clone(store.filter((request) => request.hotel_code === hotelCode));
  },

  async getById(id) {
    await wait(150);
    const found = store.find((r) => r.id === id);
    return found ? clone(found) : null;
  },

  async updateOtherRequests({ id, autres_demandes }) {
    const current = store.find((r) => r.id === id);
    if (!current) throw new Error("Demande introuvable.");
    const updated = { ...current, autres_demandes };
    store = store.map((r) => (r.id === id ? updated : r));
    return clone(updated);
  },

  async updateStatus({ id, statut, event }) {
    await wait(300);
    const index = store.findIndex((r) => r.id === id);
    if (index === -1) throw new Error(`Demande ${id} introuvable`);

    const now = new Date().toISOString();
    const current = store[index]!;
    const updated: SalesRequest = {
      ...current,
      statut,
      date_action: now,
      historique: [...(current.historique ?? []), { date: now, ...event }],
    };
    store = store.map((r, i) => (i === index ? updated : r));
    return clone(updated);
  },
};

/** Active repository: Supabase table "registre" fed by n8n. */
export const requestsRepository: RequestsRepository = googleSheetsRepository;
