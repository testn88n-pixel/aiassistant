import {
  getRegistreByIdFn,
  listRegistre as listSheetRequests,
  updateRegistreStatusFn as updateSheetRequestStatus,
  updateRegistreOtherRequestsFn,
} from "@/lib/registre.functions";
import type { RequestsRepository } from "./requests-repository";
import type { HistoryEvent, SalesRequest } from "./types";

/**
 * Builds a readable history from the dates available in the sheet.
 * No event is invented: each entry maps to a real date column.
 */
function buildHistory(request: SalesRequest): HistoryEvent[] | undefined {
  const events: HistoryEvent[] = [];

  if (request.date_email) {
    events.push({ date: request.date_email, action: "Demande reçue" });
  }
  if (request.date_traitement) {
    events.push({ date: request.date_traitement, action: "Analyse automatique" });
  }
  if (request.date_creation_devis) {
    events.push({
      date: request.date_creation_devis,
      action: "Devis généré",
      ...(request.numero_devis ? { detail: request.numero_devis } : {}),
    });
  }
  if (request.date_action) {
    events.push({
      date: request.date_action,
      action:
        request.statut === "Acceptée"
          ? "Demande acceptée"
          : request.statut === "Refusée"
            ? "Demande refusée"
            : "Statut mis à jour",
    });
  }

  if (!events.length) return undefined;
  return events.sort((a, b) => a.date.localeCompare(b.date));
}

const withHistory = (request: SalesRequest): SalesRequest => {
  const historique = request.historique?.length ? request.historique : buildHistory(request);
  return historique ? { ...request, historique } : request;
};

export const googleSheetsRepository: RequestsRepository = {
  async list(hotelCode) {
    const requests = await listSheetRequests({ data: { hotelCode } });
    return requests.map(withHistory);
  },

  async getById(id) {
    const request = await getRegistreByIdFn({ data: { id } });
    return request ? withHistory(request) : null;
  },

async updateOtherRequests(input) {
  const updated = await updateRegistreOtherRequestsFn({ data: input });
  return withHistory(updated);
},

  async updateStatus({ id, statut }) {
    const updated = await updateSheetRequestStatus({
      data: { id, statut, date_action: new Date().toISOString() },
    });
    if (!updated) throw new Error(`Demande ${id} introuvable dans la base`);
    return withHistory(updated);
  },
};
