/**
 * Data model of a group request ("demande").
 * Column names mirror the target data source (Supabase / Google Sheets).
 * Every field except `id` is optional: the UI must tolerate missing values.
 */

export const REQUEST_STATUSES = [
  "Nouvelle",
  "Attente RM",
  "RM en attente",
  "En analyse",
  "Informations manquantes",
  "Attente retour client",
  "À confirmer",
  "Prête à valider",
  "Acceptée",
  "Refusée",
] as const;

export type RequestStatus = (typeof REQUEST_STATUSES)[number];

export const CLOSED_STATUSES: RequestStatus[] = ["Acceptée", "Refusée"];

/** Statuses that require an action from the sales team. */
export const ACTION_REQUIRED_STATUSES: RequestStatus[] = [
  "Informations manquantes",
  "À confirmer",
  "Prête à valider",
];

export type FeasibilityStatus =
  | "Disponible"
  | "Non disponible"
  | "Informations manquantes"
  | "À confirmer";

export type YesNo = "Oui" | "Non";

export interface QuoteLine {
  libelle: string;
  categorie: "Hébergement" | "Séminaire" | "Pauses" | "F&B" | "Autre";
  quantite: number;
  unite: string;
  prix_unitaire: number;
  total: number;
}

export interface HistoryEvent {
  date: string; // ISO datetime
  action: string;
  detail?: string;
}

export interface NightPrice {
  date: string;
  prix_bb?: number | undefined;
}

export interface SeminairePlanningItem {
  date: string; // YYYY-MM-DD
  salle: string;
  disposition: string;
  duree: "journee" | "demi_journee";
  prix: number;
}

export type FbPrestationType =
  | "cafe_accueil"
  | "pause_matin"
  | "pause_apres_midi"
  | "dejeuner"
  | "diner"
  | "cocktail";

export interface FbPlanningItem {
  date: string; // YYYY-MM-DD ou vide
  prestation: FbPrestationType;
  libelle: string;
  pax: number;
  prix_unitaire: number;
  total: number;
}

export interface SalesRequest {
  // IDENTIFICATION
  id: string;
    hotel_code?: string;
  date_traitement?: string;
  societe?: string;
  nom_groupe?: string;
  contact?: string;
  email?: string;
  date_email?: string;
  subject?: string;
  statut: RequestStatus;
  date_action?: string;
  /** Client a répondu après validation : la demande sort des relances. */
  repondu?: boolean;
  
  // HÔTEL / HÉBERGEMENT
  hotel?: string;
  date_debut?: string;
  date_fin?: string;
  nombre_nuits?: number;
  pax?: number;
  chambres?: number;
  categorie?: string;
  type_chambre?: string;
  chambres_disponibles?: number;
  statut_hebergement?: FeasibilityStatus;
  raison_hebergement?: string;

  // SÉMINAIRE
  seminaire_demande?: YesNo;
  seminaire_date?: string;
  seminaire_heure_debut?: string;
  seminaire_heure_fin?: string;
  seminaire_pax?: number;
  seminaire_planning?: SeminairePlanningItem[];
  seminaire_jours?: SeminairePlanningItem[];
  seminaire_salle_demandee?: string;
  seminaire_salle_proposee?: string;
  seminaire_capacite?: number;
  seminaire_disponible?: YesNo;
  seminaire_statut?: FeasibilityStatus;
  seminaire_raison?: string;
  seminaire_salle_prix?: number;
  seminaire_salle_unite?: string;
  seminaire_disposition?: string;

  // PAUSES
  pause_matin_demande?: YesNo;
  pause_matin_disponible?: YesNo;
  pause_matin_prix?: number;
  pause_matin_unite?: string;
  pause_apres_midi_demande?: YesNo;
  pause_apres_midi_disponible?: YesNo;
  pause_apres_midi_prix?: number;
  pause_apres_midi_unite?: string;

  // CAFÉ D'ACCUEIL
  cafe_d_accueil_detecte?: YesNo;
  cafe_d_accueil_disponible?: YesNo;
  cafe_d_accueil_prix?: number;
  cafe_d_accueil_unite?: string;

  // F&B
  fb_demande?: YesNo;
  fb_planning?: FbPlanningItem[];
  total_seminaire?: number;
  total_fb?: number;
  total_hebergement?: number;
  fb_pax?: number;
  fb_localisation?: string;
  dejeuner_demande?: YesNo;
  dejeuner_disponible?: YesNo;
  diner_demande?: YesNo;
  diner_disponible?: YesNo;
  fb_statut?: FeasibilityStatus;
  fb_raison?: string;

  // INFOS SUPPLÉMENTAIRES
  urgent?: boolean;
  deadline_reponse?: string;
  occasion?: string;
  budget_client?: string;
  autres_demandes?: string;
  mettre_en_copie?: string; 
  emails_copie?: string;    

  // ALTERNATIVES
  alternatives_seminaire?: string;
  alternatives_hebergement?: string;
  
  // PRIX F&B
  fb_cocktail_prix?: number;
  fb_cocktail_unite?: string;
  fb_dejeuner_prix?: number;
  fb_dejeuner_unite?: string;
  fb_diner_prix?: number;
  fb_diner_unite?: string;
  fb_dejeuner_assis_prix?: number;
  fb_dejeuner_assis_unite?: string;
  fb_diner_assis_prix?: number;
  fb_diner_assis_unite?: string;

  // COMPLÉTUDE
statut_completude?:
  | "Complète"
  | "Incomplète"
  | "complet"
  | "a_completer"
  | "trop_vague";
  champs_manquants?: string[];
  question_clarification?: string;

  // PRICING / RM
tarif_recommande?: string;
  devise?: string;
  unite_tarif?: string;
  origine_tarif?: string;
  methode_tarif?: string;
  raison_tarif?: string
  tarifs_par_nuit?: NightPrice[];
  rm_requis?: YesNo;
  demande_rm?: string;
  reponse_rm?: string;

  // DEVIS
  numero_devis?: string;
  date_creation_devis?: string;
  statut_devis?: string;
  total_devis?: number;
  recap_devis?: QuoteLine[];
  devis_lien?: string;
  devis_fichier_id?: string;
  devis_version?: number;
  devis_genere_le?: string;


  // EMAIL
  email_original?: string;

  // DÉTECTION IA
  dates_detectees?: string;
  nuits_detectees?: string;
  chambres_detectees?: string;
  pax_detectes?: string;
  type_chambre_detecte?: string;
  seminaire_detecte?: string;
  horaires_detectes?: string;
  dejeuner_detecte?: string;
  pauses_detectees?: string;
  informations_manquantes?: string[];

  // RÉPONSE
  email_reponse?: string;

  // HISTORIQUE
  historique?: HistoryEvent[];
}
