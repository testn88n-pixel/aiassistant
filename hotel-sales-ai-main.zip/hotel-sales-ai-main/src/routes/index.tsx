import { createFileRoute, redirect } from "@tanstack/react-router";

// The application entry point is the Dashboard.
export const Route = createFileRoute("/")({
  beforeLoad: () => {
    throw redirect({ to: "/dashboard" });
  },
});
