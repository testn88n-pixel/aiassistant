import { createFileRoute } from "@tanstack/react-router";

import { RequestsListPage } from "@/components/requests/RequestsListPage";
import { byMostRecentAction, isAccepted, requestsQueryOptions } from "@/data/requests.queries";

export const Route = createFileRoute("/_authenticated/demandes-acceptees")({
  head: () => ({
    meta: [
      { title: "Demandes envoyées — Sales Assistant" },
      { name: "description", content: "Demandes groupes validées et envoyées au client." },
      { property: "og:title", content: "Demandes envoyées — Sales Assistant" },
      { property: "og:description", content: "Demandes groupes validées et envoyées au client." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(requestsQueryOptions),
  component: AcceptedPage,
});

function AcceptedPage() {
  return (
    <RequestsListPage
      title="Demandes envoyées"
      description="Demandes validées et transmises"
      filter={isAccepted}
      sort={byMostRecentAction}
      emptyMessage="Aucune demande envoyée pour le moment."
      enableDateFilters
    />
  );
}
