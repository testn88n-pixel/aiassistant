import { createFileRoute } from "@tanstack/react-router";

import { RequestsListPage } from "@/components/requests/RequestsListPage";
import { isActive, requestsQueryOptions } from "@/data/requests.queries";
import { REQUEST_STATUSES, type RequestStatus } from "@/data/types";

const ACTIVE_STATUS_OPTIONS: RequestStatus[] = [
  "Nouvelle",
  "Attente RM",
  "Informations manquantes",
  "Prête à valider",
];


export const Route = createFileRoute("/_authenticated/demandes/")({
  head: () => ({
    meta: [
      { title: "Demandes en cours — Sales Assistant" },
      { name: "description", content: "Liste des demandes groupes actives à traiter par le service commercial." },
      { property: "og:title", content: "Demandes en cours — Sales Assistant" },
      { property: "og:description", content: "Liste des demandes groupes actives à traiter par le service commercial." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(requestsQueryOptions),
  component: DemandesPage,
});

function DemandesPage() {
  return (
    <RequestsListPage
      title="Demandes"
      description="Demandes groupes en cours de traitement"
      filter={isActive}
      statusOptions={ACTIVE_STATUS_OPTIONS}
      emptyMessage="Aucune demande en cours."
    />
  );
}
