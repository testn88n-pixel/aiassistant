import { createFileRoute } from "@tanstack/react-router";

import { RequestsListPage } from "@/components/requests/RequestsListPage";
import { byMostRecentAction, isFollowUpDue, requestsQueryOptions } from "@/data/requests.queries";

function getDaysElapsed(dateStr?: string | null): number | null {
  if (!dateStr) return null;
  const past = new Date(dateStr).getTime();
  const now = Date.now();
  const diffDays = Math.floor((now - past) / (1000 * 60 * 60 * 24));
  return isNaN(diffDays) ? null : diffDays;
}

export const Route = createFileRoute("/_authenticated/relances")({
  head: () => ({
    meta: [
      { title: "Relances — OKKOSMART" },
      { name: "description", content: "Demandes envoyées en attente de relance après 7 jours." },
      { property: "og:title", content: "Relances — OKKOSMART" },
      { property: "og:description", content: "Demandes envoyées en attente de relance après 7 jours." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(requestsQueryOptions),
  component: RelancesPage,
});

function RelancesPage() {
  return (
    <RequestsListPage
      title="Relances"
      description="Demandes envoyées depuis 7 jours ou plus sans confirmation"
      filter={isFollowUpDue}
      sort={byMostRecentAction}
      emptyMessage="Aucune demande à relancer pour le moment."
    />
  );
}
