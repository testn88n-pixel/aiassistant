// src/routes/_authenticated.demandes.$id.tsx
import { toast } from "sonner";
import { useHotel } from "@/lib/hotel-context";
import { hasValue } from "@/lib/format";
import { modifyDevisFn } from "@/lib/n8n.functions";
import { useServerFn } from "@tanstack/react-start";
import { useQueryClient } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { Copy } from "lucide-react";

import {
  buildInitialFbPlanning,
  buildInitialSeminairePlanning,
  isLodgingUnavailable,
  isRmRefused,
} from "@/lib/planning-utils";
import type { FbPlanningItem, SeminairePlanningItem } from "@/data/types";

import { useSuspenseQuery } from "@tanstack/react-query";
import { Link, createFileRoute, notFound } from "@tanstack/react-router";

import { PageContent, PageHeader } from "@/components/layout/PageHeader";
import { AiInsightsSection } from "@/components/requests/detail/AiInsightsSection";
import { QuoteTotalsBar } from "@/components/requests/detail/QuoteTotalsBar";
import { DetailTabs } from "@/components/requests/detail/DetailTabs";
import { FeasibilitySection } from "@/components/requests/detail/FeasibilitySection";
import { FinalActions } from "@/components/requests/detail/FinalActions";
import { PricingSection } from "@/components/requests/detail/PricingSection";
import { RequestHeader } from "@/components/requests/detail/RequestHeader";
import { Button } from "@/components/ui/button";
import { useClaimAssignation } from "@/data/assignations.queries";
import { requestKeys, requestQueryOptions, useSavePrices } from "@/data/requests.queries";
import type { NightPrice, SalesRequest } from "@/data/types";
import { supabase } from "@/integrations/supabase/client";


export const Route = createFileRoute("/_authenticated/demandes/$id")({
  loader: async ({ context, params }) => {
    const request = await context.queryClient.ensureQueryData(requestQueryOptions(params.id));
    if (!request) throw notFound();
    return { request };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return { meta: [{ title: "Demande introuvable — Sales Assistant" }, { name: "robots", content: "noindex" }] };
    }
    const r = loaderData.request;
    const title = `${r.societe ?? r.id} — Demande ${r.id} — Sales Assistant`;
    const description = `Détail de la demande groupe ${r.id}${r.societe ? ` de ${r.societe}` : ""} : faisabilité, pricing, devis et réponse client.`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
      ],
    };
  },
  pendingComponent: RequestDetailSkeleton,
  notFoundComponent: RequestNotFound,
  component: RequestDetailPage,
});


function RequestDetailSkeleton() {
  return (
    <>
      <PageHeader title="Chargement de la demande..." />
      <PageContent className="space-y-6">
        {/* En-tête skeleton */}
        <div className="surface-card p-6 space-y-4 animate-pulse">
          <div className="flex justify-between items-center pb-3 border-b border-border/40">
            <div className="h-4 w-28 bg-muted rounded" />
            <div className="h-6 w-32 bg-muted rounded" />
          </div>
          <div className="h-7 w-64 bg-muted rounded" />
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-2">
            <div className="h-14 bg-muted/60 rounded" />
            <div className="h-14 bg-muted/60 rounded" />
            <div className="h-14 bg-muted/60 rounded" />
            <div className="h-14 bg-muted/60 rounded" />
          </div>
        </div>
        {/* Blocs Faisabilité skeleton */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-pulse">
          <div className="lg:col-span-5 h-64 bg-muted/40 rounded-xl surface-card" />
          <div className="lg:col-span-4 h-64 bg-muted/40 rounded-xl surface-card" />
          <div className="lg:col-span-3 h-64 bg-muted/40 rounded-xl surface-card" />
        </div>
      </PageContent>
    </>
  );
}

function RequestNotFound() {
  return (
    <>
      <PageHeader title="Demande introuvable" />
      <PageContent>
        <div className="surface-card p-10 text-center">
          <p className="text-sm text-muted-foreground">Cette demande n'existe pas ou n'est plus disponible.</p>
          <Button asChild variant="outline" className="mt-4">
<Link
  to="/demandes"
  className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground mb-3 font-medium transition-colors"
>
  ← Retour aux demandes
</Link>
          </Button>
        </div>
      </PageContent>
    </>
  );
}

export interface PrestationPrices {
  tarif_recommande?: string | undefined;
  seminaire_salle_prix?: number | undefined;
  cafe_d_accueil_prix?: number | undefined;
  pause_matin_prix?: number | undefined;
  pause_apres_midi_prix?: number | undefined;
  fb_cocktail_prix?: number | undefined;
  fb_dejeuner_prix?: number | undefined;
  fb_diner_prix?: number | undefined;
  fb_dejeuner_assis_prix?: number | undefined;
  fb_diner_assis_prix?: number | undefined;
}

function buildInitialNightPrices(r?: SalesRequest | null): NightPrice[] {
  if (!r) return [];

  if (isRmRefused(r) || isLodgingUnavailable(r)) {
    return [];
  }

  if (r.tarifs_par_nuit && r.tarifs_par_nuit.length > 0) {
    return r.tarifs_par_nuit;
  }

  const rawTarif = r.tarif_recommande;
  const parsedPrices = rawTarif
    ? rawTarif.split(";").map((s) => Number(s.trim()))
    : [];

  const nbNuits = r.nombre_nuits ?? (parsedPrices.length > 0 ? parsedPrices.length : 1);

  if (r.date_debut && nbNuits > 0) {
    const list: NightPrice[] = [];
    const start = new Date(r.date_debut);

    if (!isNaN(start.getTime())) {
      for (let i = 0; i < nbNuits; i++) {
        const d = new Date(start);
        d.setDate(d.getDate() + i);
        const isoDate = d.toISOString().split("T")[0] ?? "";

        const prix =
          parsedPrices.length === 1
            ? parsedPrices[0]
            : (parsedPrices[i] ?? parsedPrices[0]);

        list.push({
          date: isoDate,
          prix_bb: Number.isFinite(prix) ? prix : undefined,
        });
      }
      return list;
    }
  }
  return [];
}

function RequestDetailPage() {
  const { id } = Route.useParams();
  const { data: request } = useSuspenseQuery(requestQueryOptions(id));

  const queryClient = useQueryClient();
  const modifyDevisServerFn = useServerFn(modifyDevisFn);
  const { hotel } = useHotel();
  const [isModifyingDevis, setIsModifyingDevis] = useState(false);
  const [hasUnsyncedModifications, setHasUnsyncedModifications] = useState(false);

  const [emailDraft, setEmailDraft] = useState(request?.email_reponse ?? "");
  const [isDirty, setIsDirty] = useState(false);

  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (isDirty) {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => window.removeEventListener("beforeunload", handleBeforeUnload);
  }, [isDirty]);

  const [nightPrices, setNightPrices] = useState<NightPrice[]>(() => buildInitialNightPrices(request));
  const [seminairePlanning, setSeminairePlanning] = useState<SeminairePlanningItem[]>(
    () => buildInitialSeminairePlanning(request)
  );
  const [fbPlanning, setFbPlanning] = useState<FbPlanningItem[]>(
    () => buildInitialFbPlanning(request)
  );
  const savePricesMutation = useSavePrices();

  const handleSavePrices = () => {
    if (!request) return;
    const totalSeminaireSallesOnly = seminairePlanning.reduce(
      (sum, item) => sum + (Number(item.prix) || 0),
      0
    );
    savePricesMutation.mutate({
      id: request.id,
      seminaire_jours: JSON.stringify(seminairePlanning),
      total_seminaire: totalSeminaireSallesOnly,
    });
  };

  useEffect(() => {
    if (request) {
      setSeminairePlanning(buildInitialSeminairePlanning(request));
      setFbPlanning(buildInitialFbPlanning(request));
    }
  }, [request?.id]);

  const handleSeminairePriceChange = (index: number, newPrice: number) => {
    setSeminairePlanning((prev) => {
      const copy = [...prev];
      if (copy[index]) {
        copy[index] = { ...copy[index]!, prix: newPrice };
      }
      return copy;
    });
  };
  const handleSeminaireItemChange = (
    index: number,
    updates: Partial<SeminairePlanningItem>
  ) => {
    setSeminairePlanning((prev) => {
      const copy = [...prev];
      if (copy[index]) {
        copy[index] = { ...copy[index]!, ...updates };
      }
      return copy;
    });
  };

  const handleFbItemChange = (index: number, field: "pax" | "prix_unitaire", val: number) => {
    setFbPlanning((prev) => {
      const copy = [...prev];
      const target = copy[index];
      if (target) {
        const newPax = field === "pax" ? val : target.pax;
        const newPrix = field === "prix_unitaire" ? val : target.prix_unitaire;
        copy[index] = {
          ...target,
          [field]: val,
          total: Math.round(newPax * newPrix * 100) / 100,
        };
      }
      return copy;
    });
  };

  // Calcul du total hébergement
  const totalRooms = request?.chambres ?? 1;
  const sumNightPrices = nightPrices.reduce((sum, n) => sum + (n.prix_bb ?? 0), 0);
  const totalHebergement = sumNightPrices * totalRooms;
  const handleSaveHebergementPrices = () => {
    if (!request) return;
    savePricesMutation.mutate({
      id: request.id,
      tarifs_par_nuit: nightPrices,
      total_hebergement: totalHebergement,
    });
  };

  const handleSaveFbPrices = () => {
    if (!request) return;
    const totalAllFb = fbPlanning.reduce((sum, item) => sum + (Number(item.total) || 0), 0);
    savePricesMutation.mutate({
      id: request.id,
      fb_planning: fbPlanning,
      total_fb: totalAllFb,
    });
  };

  const handleModifyDevis = async (commentaire?: string) => {
    if (!request) return;
    setIsModifyingDevis(true);
    try {
      const formattedTarifRecommande = nightPrices
        .map((n) => n.prix_bb ?? 0)
        .join(";");

      const totalSeminaireSalles = seminairePlanning.reduce((sum, item) => sum + (Number(item.prix) || 0), 0);
      const totalAllFb = fbPlanning.reduce((sum, item) => sum + (Number(item.total) || 0), 0);

      // 1. Sauvegarde d'abord dans Supabase
      await savePricesMutation.mutateAsync({
        id: request.id,
        tarif_recommande: formattedTarifRecommande,
        ...(request.chambres !== undefined ? { chambres: request.chambres } : {}),
        ...(request.pax !== undefined ? { pax: request.pax } : {}),
        tarifs_par_nuit: nightPrices,
        total_hebergement: totalHebergement,
        seminaire_jours: JSON.stringify(seminairePlanning),
        total_seminaire: totalSeminaireSalles,
        fb_planning: fbPlanning,
        total_fb: totalAllFb,
        total_devis: totalDevis,
      });

      // 2. Récupère l'email de l'utilisateur connecté
      const { data: authData } = await supabase.auth.getUser();
      const userEmail = authData.user?.email ?? undefined;

      // 3. Appel n8n
            const result = await modifyDevisServerFn({
        data: {
          id: request.id,
          commentaire: commentaire && commentaire.trim().length > 0 ? commentaire.trim() : undefined,
          modifie_par: userEmail,
          hotel: hotel?.nom ?? "",
          hotel_code: hotel?.code ?? "",
          hotel_adresse: hotel?.adresse ?? "",
        },
      });


      if (result.ok) {
        toast.success(`Devis v${result.devis_version ?? ""} généré`);
        setHasUnsyncedModifications(false);
        await queryClient.invalidateQueries({ queryKey: requestKeys.detail(request.id) });
      } else {
        toast.error("La génération du devis a échoué, réessayez");
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "La génération du devis a échoué, réessayez");
    } finally {
      setIsModifyingDevis(false);
    }
  };

  
    // Rafraîchissement automatique toutes les 15 secondes pendant 2 minutes max si devis_lien est vide
  useEffect(() => {
    if (!request || hasValue(request.devis_lien) || request.statut === "Attente RM") return;

    let pollCount = 0;
    const interval = setInterval(() => {
      pollCount += 1;
      queryClient.invalidateQueries({ queryKey: requestKeys.detail(request.id) });
      if (pollCount >= 8) { // 8 x 15s = 120s (2 minutes)
        clearInterval(interval);
      }
    }, 15000);

    return () => clearInterval(interval);
  }, [request?.id, request?.devis_lien, request?.statut]);


  // Attribution automatique au premier commercial ouvrant la demande
  const claimAssignation = useClaimAssignation();
  const autoClaimedRef = useRef<string | null>(null);
  useEffect(() => {
    const demandeId = request?.id;
    if (!demandeId || autoClaimedRef.current === demandeId) return;
    autoClaimedRef.current = demandeId;
    void supabase.auth.getUser().then(({ data }) => {
      const u = data.user;
      if (!u?.email) return;
      const meta = u.user_metadata?.["full_name"] as string | undefined;
      const raw = meta?.trim() || u.email.split("@")[0] || "Commercial";
      claimAssignation.mutate({
        demande_id: demandeId,
        user_id: u.id,
        user_name: raw.charAt(0).toUpperCase() + raw.slice(1),
        user_email: u.email,
      });
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [request?.id]);


  const handleNightPriceChange = (index: number, val: number | undefined) => {
    setNightPrices((prev) => {
      const copy = [...prev];
      const target = copy[index];
      if (target) {
        copy[index] = { date: target.date, prix_bb: val };
      }
      return copy;
    });
  };

  const [prices, setPrices] = useState<PrestationPrices>({
    tarif_recommande: request?.tarif_recommande,
    seminaire_salle_prix: request?.seminaire_salle_prix,
    cafe_d_accueil_prix: request?.cafe_d_accueil_prix,
    pause_matin_prix: request?.pause_matin_prix,
    pause_apres_midi_prix: request?.pause_apres_midi_prix,
    fb_cocktail_prix: request?.fb_cocktail_prix,
    fb_dejeuner_prix: request?.fb_dejeuner_prix,
    fb_diner_prix: request?.fb_diner_prix,
    fb_dejeuner_assis_prix: request?.fb_dejeuner_assis_prix,
    fb_diner_assis_prix: request?.fb_diner_assis_prix,
  });

  useEffect(() => {
    setEmailDraft(request?.email_reponse ?? "");
    if (request) {
      setPrices({
        tarif_recommande: request.tarif_recommande,
        seminaire_salle_prix: request.seminaire_salle_prix,
        cafe_d_accueil_prix: request.cafe_d_accueil_prix,
        pause_matin_prix: request.pause_matin_prix,
        pause_apres_midi_prix: request.pause_apres_midi_prix,
        fb_cocktail_prix: request.fb_cocktail_prix,
        fb_dejeuner_prix: request.fb_dejeuner_prix,
        fb_diner_prix: request.fb_diner_prix,
        fb_dejeuner_assis_prix: request.fb_dejeuner_assis_prix,
        fb_diner_assis_prix: request.fb_diner_assis_prix,
      });
    }
  }, [request?.id, request?.email_reponse]);
  
  const handlePriceChange = (key: keyof PrestationPrices, val: number | undefined) => {
    setPrices((prev) => ({ ...prev, [key]: val }));
  };

  if (!request) return <RequestNotFound />;

  // Pauses et cafés rattachés au Séminaire
  const isPauseOrCafe = (p: string) =>
    p === "cafe_accueil" || p === "pause_matin" || p === "pause_apres_midi";

  const totalPausesCafe = fbPlanning
    .filter((item) => isPauseOrCafe(item.prestation))
    .reduce((sum, item) => sum + (Number(item.total) || 0), 0);

  const totalRestaurant = fbPlanning
    .filter((item) => !isPauseOrCafe(item.prestation))
    .reduce((sum, item) => sum + (Number(item.total) || 0), 0);

  const totalSeminaireSalles = seminairePlanning.reduce((sum, item) => sum + (Number(item.prix) || 0), 0);
  const totalSeminaire = totalSeminaireSalles + totalPausesCafe;
  const totalFb = totalRestaurant;
  const totalDevis = totalHebergement + totalSeminaire + totalFb;
  const currencySymbol = !request.devise || request.devise === "EUR" ? "€" : request.devise;


  return (
    <>
<PageHeader 
  title="Détail de la demande" 
  description={request.numero_devis ? `Devis ${request.numero_devis}` : (request.nom_groupe ?? undefined)} 
/>
            <PageContent className="space-y-10">
        {isDirty && (
          <div className="flex items-center justify-between gap-3 rounded-lg border border-amber-500/30 bg-amber-500/10 px-4 py-2 text-xs text-amber-700 dark:text-amber-300">
            <div className="flex items-center gap-2">
              <span className="inline-block size-2 rounded-full bg-amber-500 animate-pulse" />
              <span className="font-medium">Modifications non enregistrées sur les tarifs</span>
            </div>
            <span className="text-[11px] opacity-80">Pensez à cliquer sur « Enregistrer les prix » avant de quitter</span>
          </div>
        )}
        <RequestHeader request={request} />
        <AiInsightsSection request={request} />
        <PricingSection
          request={request}
          nightPrices={nightPrices}
          onNightPriceChange={handleNightPriceChange}
          onSavePrices={handleSaveHebergementPrices}
          isSavingPrices={savePricesMutation.isPending}
        />
        <FeasibilitySection
          request={request}
          seminairePlanning={seminairePlanning}
          fbPlanning={fbPlanning}
          onSeminairePriceChange={handleSeminairePriceChange}
          onSeminaireItemChange={handleSeminaireItemChange}
          onFbItemChange={handleFbItemChange}
          totalHebergement={totalHebergement}
          onSavePrices={handleSavePrices}
          isSavingPrices={savePricesMutation.isPending}
          onSaveFbPrices={handleSaveFbPrices}
          isSavingFbPrices={savePricesMutation.isPending}
        />
        <QuoteTotalsBar
          totalHebergement={totalHebergement}
          totalSeminaire={totalSeminaire}
          totalFb={totalFb}
          totalDevis={totalDevis}
          currency={currencySymbol}
        />
        <DetailTabs
          request={request}
          draft={emailDraft}
          onDraftChange={setEmailDraft}
          onModifyDevis={handleModifyDevis}
          isModifyingDevis={isModifyingDevis}
        />
        <FinalActions
            hasUnsyncedModifications={hasUnsyncedModifications}
  onGenerateAndValidate={async () => {
    await handleModifyDevis();
  }}
          request={request}
          emailDraft={emailDraft}
          nightPrices={nightPrices}
          seminairePlanning={seminairePlanning}
          fbPlanning={fbPlanning}
        />
      </PageContent>
    </>
  );
}
