import { Outlet, createFileRoute, redirect } from "@tanstack/react-router";
import { lazy } from "react";

import { AppSidebar } from "@/components/layout/AppSidebar";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { HotelProvider } from "@/lib/hotel-context";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) throw redirect({ to: "/auth" });
    return { user: data.user };
  },
  component: AuthenticatedLayout,
  errorComponent: lazy(() => Promise.resolve({ default: DataErrorScreen })),
});

function AuthenticatedLayout() {
  return (
    <HotelProvider>
      <div className="min-h-screen bg-background">
        <AppSidebar />
        <main className="min-h-screen pl-44">
          <Outlet />
        </main>
      </div>
    </HotelProvider>
  );
}

function DataErrorScreen({ error }: { error: unknown }) {
  const errorMessage = error instanceof Error ? error.message : undefined;
  return (
    <div className="min-h-screen bg-background">
      <AppSidebar />
      <main className="min-h-screen pl-44">
        <div className="mx-auto flex min-h-screen max-w-xl flex-col justify-center gap-4 px-8">
          <p className="eyebrow text-muted-foreground">Source de données</p>
          <h1 className="text-2xl font-semibold text-foreground">
            Les demandes n'ont pas pu être chargées
          </h1>
          <p className="text-sm text-muted-foreground">
            La connexion à la base des demandes a échoué. Réessayez dans un instant.
          </p>
          {errorMessage ? (
            <p className="rounded-md border border-border bg-muted/40 p-3 text-xs text-muted-foreground">
              {errorMessage}
            </p>
          ) : null}
          <div>
            <Button onClick={() => window.location.reload()}>Réessayer</Button>
          </div>
        </div>
      </main>
    </div>
  );
}
