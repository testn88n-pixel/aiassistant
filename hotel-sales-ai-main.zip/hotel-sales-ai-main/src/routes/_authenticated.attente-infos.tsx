import { createFileRoute } from "@tanstack/react-router";

import { RequestsListPage } from "@/components/requests/RequestsListPage";
import { isWaitingClient, requestsQueryOptions } from "@/data/requests.queries";

export const Route = createFileRoute("/_authenticated/attente-infos")({
  head: () => ({
    meta: [
      { title: "Attente infos — Sales Assistant" },
      { name: "description", content: "Demandes en attente de retour d'informations client." },
      { property: "og:title", content: "Attente infos — Sales Assistant" },
      { property: "og:description", content: "Demandes en attente de retour d'informations client." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(requestsQueryOptions),
  component: AttenteInfosPage,
});

function AttenteInfosPage() {
  return (
    <RequestsListPage
      title="Attente retour client"
      description="Demandes pour lesquelles des précisions ont été demandées au client"
      filter={isWaitingClient}
      emptyMessage="Aucune demande en attente de retour client."
    />
  );
}
