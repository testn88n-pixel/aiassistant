import { useEffect, useMemo, useState } from "react";
import { useSuspenseQuery } from "@tanstack/react-query";
import { Link, createFileRoute } from "@tanstack/react-router";
import {
  AlertTriangle,
  ArrowRight,
  Bell,
  CheckCircle2,
  Inbox,
  X,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

import { PageContent, PageHeader } from "@/components/layout/PageHeader";
import { StatusBadge } from "@/components/requests/StatusBadge";
import { Button } from "@/components/ui/button";
import { useAssignations } from "@/data/assignations.queries";
import {
  byMostRecentEmail,
  isAccepted,
  isActive,
  isFollowUpDue,
  requestsQueryOptions,
} from "@/data/requests.queries";
import type { SalesRequest } from "@/data/types";
import { supabase } from "@/integrations/supabase/client";
import { formatDateRange, formatNumber, hasValue } from "@/lib/format";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — OKKOSMART" },
      { name: "description", content: "Vue d'ensemble de l'activité commerciale groupes de l'hôtel." },
      { property: "og:title", content: "Dashboard — OKKOSMART" },
      { property: "og:description", content: "Vue d'ensemble de l'activité commerciale groupes de l'hôtel." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(requestsQueryOptions),
  component: DashboardPage,
});

function getDaysUntil(dateStr?: string | null): number | null {
  if (!dateStr) return null;
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return null;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const target = new Date(d);
  target.setHours(0, 0, 0, 0);
  return Math.round((target.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
}

interface PriorityItem {
  request: SalesRequest;
  label: string;
  badgeTone: "danger" | "warning" | "primary";
}

function KpiCard({
  label,
  value,
  icon: Icon,
  to,
  tone,
}: {
  label: string;
  value: number;
  icon: LucideIcon;
  to: "/demandes" | "/demandes-acceptees" | "/relances";
  tone: "primary" | "success" | "danger" | "warning";
}) {
  return (
    <Link to={to} className="surface-card group flex items-center gap-4 p-5 transition-shadow hover:shadow-elevated">
      <div
        className={cn(
          "flex size-11 shrink-0 items-center justify-center rounded-lg",
          tone === "primary" && "bg-secondary text-primary",
          tone === "success" && "bg-success-soft text-success",
          tone === "danger" && "bg-danger-soft text-danger",
          tone === "warning" && "bg-warning-soft text-warning"
        )}
      >
        <Icon className="size-5" />
      </div>
      <div className="min-w-0 flex-1">
        <p className="eyebrow">{label}</p>
        <p className="tabular mt-0.5 font-display text-3xl font-semibold text-foreground">{value}</p>
      </div>
      <ArrowRight className="size-4 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
    </Link>
  );
}

function PriorityRow({ item, onSelect }: { item: PriorityItem; onSelect?: () => void }) {
  const stay = formatDateRange(item.request.date_debut, item.request.date_fin);
  return (
    <Link
      to="/demandes/$id"
      params={{ id: item.request.id }}
      onClick={onSelect}
      className="group flex items-center justify-between gap-3 px-4 py-3 transition-colors hover:bg-accent"
    >
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <span
            className={cn(
              "inline-flex items-center rounded-md px-2 py-0.5 text-xs font-semibold",
              item.badgeTone === "danger" && "bg-danger-soft text-danger",
              item.badgeTone === "warning" && "bg-warning-soft text-warning",
              item.badgeTone === "primary" && "bg-secondary text-primary"
            )}
          >
            {item.label}
          </span>
          <p className="truncate text-sm font-semibold text-foreground">
            {item.request.societe ?? item.request.id}
            {hasValue(item.request.nom_groupe) && (
              <span className="font-normal text-muted-foreground"> · {item.request.nom_groupe}</span>
            )}
          </p>
        </div>
        <p className="mt-0.5 truncate text-xs text-muted-foreground">
          {[
            stay,
            hasValue(item.request.pax) ? `${formatNumber(item.request.pax)} pax` : undefined,
            hasValue(item.request.chambres) ? `${formatNumber(item.request.chambres)} ch.` : undefined,
          ]
            .filter(Boolean)
            .join(" · ")}
        </p>
      </div>
      <ArrowRight className="size-4 text-muted-foreground opacity-60 transition-transform group-hover:translate-x-0.5 group-hover:opacity-100" />
    </Link>
  );
}

function RequestRow({ request }: { request: SalesRequest }) {
  const { data: assignations } = useAssignations();
  const stay = formatDateRange(request.date_debut, request.date_fin);
  const displayStatus =
    request.statut === "Nouvelle" && assignations?.[request.id]
      ? "Prête à valider"
      : request.statut;

  return (
    <Link
      to="/demandes/$id"
      params={{ id: request.id }}
      className="flex items-center gap-4 px-5 py-3.5 transition-colors hover:bg-accent"
    >
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-semibold text-foreground">
          {request.societe ?? request.id}
          {hasValue(request.nom_groupe) && (
            <span className="font-normal text-muted-foreground"> · {request.nom_groupe}</span>
          )}
        </p>
        <p className="mt-0.5 truncate text-xs text-muted-foreground">
          {[
            stay,
            hasValue(request.pax) ? `${formatNumber(request.pax)} pax` : undefined,
            hasValue(request.chambres) ? `${formatNumber(request.chambres)} ch.` : undefined,
          ]
            .filter(Boolean)
            .join(" · ")}
        </p>
      </div>
      <StatusBadge status={displayStatus} />
    </Link>
  );
}

function Panel({
  title,
  subtitle,
  children,
  action,
}: {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  action?: React.ReactNode;
}) {
  return (
    <section className="surface-card overflow-hidden">
      <header className="flex items-center justify-between gap-3 border-b border-border px-5 py-4">
        <div>
          <h2 className="text-base font-semibold text-foreground">{title}</h2>
          {subtitle && <p className="text-xs text-muted-foreground">{subtitle}</p>}
        </div>
        {action}
      </header>
      {children}
    </section>
  );
}

function DashboardPage() {
  const { data: requests } = useSuspenseQuery(requestsQueryOptions);

  const [userName, setUserName] = useState<string>("");
  const [prioritiesOpen, setPrioritiesOpen] = useState(false);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      const u = data.user;
      if (u) {
const meta = (u.user_metadata?.['full_name'] as string) || (u.user_metadata?.['name'] as string);
        const raw = meta?.trim() || u.email?.split("@")[0] || "";
        const formatted = raw ? raw.charAt(0).toUpperCase() + raw.slice(1) : "";
        setUserName(formatted);
      }
    });
  }, []);

  const active = requests.filter(isActive);
  const accepted = requests.filter(isAccepted);
  const followUp = requests.filter(isFollowUpDue);
  const recentActive = useMemo(() => [...active].sort(byMostRecentEmail), [active]);

  // Date du jour & salutation
  const todayFormatted = new Intl.DateTimeFormat("fr-FR", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(new Date());
  const displayDate = todayFormatted.charAt(0).toUpperCase() + todayFormatted.slice(1);

  const hour = new Date().getHours();
  const salutation = hour < 12 ? "Bonjour" : hour < 18 ? "Bon après-midi" : "Bonsoir";
  const greeting = userName ? `${salutation} ${userName}` : salutation;

  // Calcul des priorités
  const priorityItems = useMemo(() => {
    const list: PriorityItem[] = [];
    const seenIds = new Set<string>();

    for (const r of active) {
      if (r.urgent && !seenIds.has(r.id)) {
        seenIds.add(r.id);
        list.push({ request: r, label: "Urgent", badgeTone: "danger" });
      }
    }

    for (const r of active) {
      if (r.date_debut && !seenIds.has(r.id)) {
        const d = getDaysUntil(r.date_debut);
        if (d !== null && d >= 0 && d <= 30) {
          seenIds.add(r.id);
          list.push({
            request: r,
            label: d === 0 ? "Arrivée aujourd'hui" : `Arrivée dans ${d} j`,
            badgeTone: "warning",
          });
        }
      }
    }

    for (const r of followUp) {
      if (!seenIds.has(r.id)) {
        seenIds.add(r.id);
        list.push({ request: r, label: "Relance à faire", badgeTone: "primary" });
      }
    }

    return list;
  }, [active, followUp]);

  return (
    <>
      <PageHeader title="Dashboard" description="Vue d'ensemble de l'activité groupes" />
      <PageContent className="space-y-6">
        {/* Titre central sobre */}
        <div className="py-2 text-center">
          <p className="eyebrow uppercase tracking-wider text-muted-foreground">{displayDate}</p>
          <h1 className="mt-1 font-display text-3xl font-semibold tracking-tight text-foreground">
            {greeting}
          </h1>
          <p className="mt-1.5 text-sm text-muted-foreground">
            {active.length} dossier{active.length > 1 ? "s" : ""} en cours
            {priorityItems.length > 0 && ` · ${priorityItems.length} priorité${priorityItems.length > 1 ? "s" : ""} à traiter`}
          </p>
        </div>

        {/* Les 3 blocs KPI d'origine */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <KpiCard label="Demandes en cours" value={active.length} icon={Inbox} to="/demandes" tone="primary" />
          <KpiCard label="Devis envoyés" value={accepted.length} icon={CheckCircle2} to="/demandes-acceptees" tone="success" />
          <KpiCard label="Relances à faire" value={followUp.length} icon={Bell} to="/relances" tone="warning" />
        </div>

        {/* Liste des demandes récentes */}
        <Panel
          title="Demandes récemment reçues"
          subtitle="Demandes actives en attente de traitement"
          action={
            <Button asChild variant="ghost" size="sm">
              <Link to="/demandes">Voir tout</Link>
            </Button>
          }
        >
          {recentActive.length === 0 ? (
            <p className="px-5 py-8 text-center text-sm text-muted-foreground">
              Aucune demande en cours pour le moment.
            </p>
          ) : (
            <div className="divide-y divide-border">
              {recentActive.map((r) => (
                <RequestRow key={r.id} request={r} />
              ))}
            </div>
          )}
        </Panel>

        {/* Pastille volante "Priorités" (Option A : fixée discrètement en bas à droite) */}
        {priorityItems.length > 0 && (
          <div className="fixed bottom-6 right-6 z-40">
            {!prioritiesOpen ? (
              <button
                type="button"
                onClick={() => setPrioritiesOpen(true)}
                className="flex items-center gap-2.5 rounded-full border border-border bg-card/95 px-4 py-2.5 shadow-lg backdrop-blur transition-all hover:bg-accent hover:shadow-xl focus:outline-none"
              >
                <span className="flex size-6 items-center justify-center rounded-full bg-warning-soft text-warning">
                  <AlertTriangle className="size-3.5" />
                </span>
                <span className="text-xs font-semibold text-foreground">
                  Priorités du jour
                </span>
                <span className="rounded-full bg-warning-soft px-2 py-0.5 text-xs font-semibold text-warning">
                  {priorityItems.length}
                </span>
              </button>
            ) : (
              <div className="w-[360px] max-w-[calc(100vw-3rem)] overflow-hidden rounded-xl border border-border bg-card shadow-2xl">
                <header className="flex items-center justify-between border-b border-border bg-muted/30 px-4 py-3">
                  <div className="flex items-center gap-2">
                    <span className="flex size-6 items-center justify-center rounded-full bg-warning-soft text-warning">
                      <AlertTriangle className="size-3.5" />
                    </span>
                    <span className="text-sm font-semibold text-foreground">
                      Priorités du jour
                    </span>
                    <span className="rounded-full bg-warning-soft px-1.5 py-0.5 text-xs font-semibold text-warning">
                      {priorityItems.length}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setPrioritiesOpen(false)}
                    className="rounded-md p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
                    title="Fermer"
                  >
                    <X className="size-4" />
                  </button>
                </header>
                <div className="max-h-[60vh] divide-y divide-border overflow-y-auto">
                  {priorityItems.map((item) => (
                    <PriorityRow
                      key={`${item.request.id}-${item.label}`}
                      item={item}
                      onSelect={() => setPrioritiesOpen(false)}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </PageContent>
    </>
  );
}
