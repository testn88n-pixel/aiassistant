import { createFileRoute } from "@tanstack/react-router";

import { RequestsListPage } from "@/components/requests/RequestsListPage";
import { byMostRecentAction, isRefused, requestsQueryOptions } from "@/data/requests.queries";

export const Route = createFileRoute("/_authenticated/demandes-refusees")({
  head: () => ({
    meta: [
      { title: "Demandes bloquées — Sales Assistant" },
      { name: "description", content: "Demandes groupes bloquées par le service commercial." },
      { property: "og:title", content: "Demandes bloquées — Sales Assistant" },
      { property: "og:description", content: "Demandes groupes bloquées par le service commercial." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(requestsQueryOptions),
  component: RefusedPage,
});

function RefusedPage() {
  return (
    <RequestsListPage
      title="Demandes bloquées"
      description="Demandes bloquées par le service commercial"
      filter={isRefused}
      sort={byMostRecentAction}
      emptyMessage="Aucune demande bloquée pour le moment."
    />
  );
}
