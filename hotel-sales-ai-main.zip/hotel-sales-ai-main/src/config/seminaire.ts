export type DispositionKey = "en U" | "théâtre" | "école" | "board" | "îlots";

export interface SalleCapacite {
  salle: string;
  surface: number; // en m²
  capacites: Record<DispositionKey, number | null>; // null si non disponible (ex: Lille ou Brazil en board)
  prix_journee: number;
  prix_demi_journee: number;
}

export const SALLES_PAR_HOTEL: Record<string, SalleCapacite[]> = {
  // Hôtel 1 - Le Grand Pavillon Paris / Démo Paris
  DEMO_PARIS: [
    {
      salle: "Lisbonne",
      surface: 38,
      capacites: {
        "théâtre": 30,
        "en U": 20,
        "école": 16,
        "board": 16,
        "îlots": 18,
      },
      prix_journee: 1400,
      prix_demi_journee: 700,
    },
    {
      salle: "Porto",
      surface: 35,
      capacites: {
        "théâtre": 20,
        "en U": 12,
        "école": 12,
        "board": 12,
        "îlots": 16,
      },
      prix_journee: 1100,
      prix_demi_journee: 600,
    },
    {
      salle: "Algarve",
      surface: 33,
      capacites: {
        "théâtre": 20,
        "en U": 12,
        "école": 12,
        "board": 12,
        "îlots": 16,
      },
      prix_journee: 1100,
      prix_demi_journee: 600,
    },
    {
      salle: "Brazil",
      surface: 73,
      capacites: {
        "théâtre": 70,
        "en U": 32,
        "école": 28,
        "board": null, // non disponible
        "îlots": 28,
      },
      prix_journee: 1800,
      prix_demi_journee: 950,
    },
  ],

  // Hôtel 2 - Hôtel Démo La Défense
  DEMO_PARIS_2: [
    {
      salle: "Paris",
      surface: 38,
      capacites: {
        "théâtre": 30,
        "en U": 20,
        "école": 16,
        "board": 16,
        "îlots": 18,
      },
      prix_journee: 1600,
      prix_demi_journee: 800,
    },
    {
      salle: "Marseille",
      surface: 35,
      capacites: {
        "théâtre": 20,
        "en U": 12,
        "école": 12,
        "board": 12,
        "îlots": 16,
      },
      prix_journee: 1300,
      prix_demi_journee: 650,
    },
    {
      salle: "Lyon",
      surface: 33,
      capacites: {
        "théâtre": 20,
        "en U": 12,
        "école": 12,
        "board": 12,
        "îlots": 16,
      },
      prix_journee: 1300,
      prix_demi_journee: 650,
    },
    {
      salle: "Lille",
      surface: 73,
      capacites: {
        "théâtre": 70,
        "en U": 32,
        "école": 28,
        "board": null, // 'X' : non disponible
        "îlots": 28,
      },
      prix_journee: 2000,
      prix_demi_journee: 1000,
    },
  ],
};

export const SALLES_SEMINAIRE: SalleCapacite[] = SALLES_PAR_HOTEL["DEMO_PARIS"] ?? [];

export function getSallesForHotel(hotelCode?: string): SalleCapacite[] {
  if (!hotelCode) return SALLES_SEMINAIRE;
  const normalized = hotelCode.toUpperCase().replace(/\s+/g, "_");
  const sallesTrouvees = SALLES_PAR_HOTEL[normalized];
  if (sallesTrouvees) return sallesTrouvees;
  if (normalized.includes("2") || normalized.includes("DEFENSE") || normalized.includes("DÉFENSE")) {
    return SALLES_PAR_HOTEL["DEMO_PARIS_2"] ?? SALLES_SEMINAIRE;
  }
  return SALLES_PAR_HOTEL["DEMO_PARIS"] ?? SALLES_SEMINAIRE;
}


export const DISPOSITIONS: { key: DispositionKey; label: string }[] = [
  { key: "en U", label: "En U" },
  { key: "théâtre", label: "Théâtre" },
  { key: "école", label: "École" },
  { key: "board", label: "Board" },
  { key: "îlots", label: "Îlots" },
];

export function normalizeDisposition(raw?: string): DispositionKey | null {
  if (!raw) return null;
  const s = raw
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");

  if (s === "u" || s === "en u" || s === 'en "u"') return "en U";
  if (s === "theatre") return "théâtre";
  if (s === "ecole") return "école";
  if (s === "board") return "board";
  if (s === "ilot" || s === "ilots") return "îlots";
  return null;
}

export function findSalleConfig(salleName?: string, hotelCode?: string): SalleCapacite | undefined {
  if (!salleName) return undefined;
  const target = salleName.trim().toLowerCase();

  // 1. Chercher dans l'hôtel ciblé
  const hotelRooms = getSallesForHotel(hotelCode);
  const foundInHotel = hotelRooms.find((s) => s.salle.toLowerCase() === target);
  if (foundInHotel) return foundInHotel;

  // 2. Repli : chercher dans l'ensemble des hôtels si le code hôtel n'était pas précisé
  for (const rooms of Object.values(SALLES_PAR_HOTEL)) {
    const match = rooms.find((s) => s.salle.toLowerCase() === target);
    if (match) return match;
  }

  return undefined;
}

export function getGrillePrice(
  salleName: string,
  duree: "journee" | "demi_journee",
  hotelCode?: string
): number | null {
  const conf = findSalleConfig(salleName, hotelCode);
  if (!conf) return null;
  return duree === "demi_journee" ? conf.prix_demi_journee : conf.prix_journee;
}

export interface CapacityCheckResult {
  level: "red" | "orange" | "green" | "unknown";
  message: string;
  proposals?: string | undefined;
  isRed: boolean;
}

export function checkSalleCapacity(params: {
  salleName?: string | undefined;
  dispositionRaw?: string | undefined;
  participants?: number | null | undefined;
  hotelCode?: string | undefined;
}): CapacityCheckResult {
  const { salleName, dispositionRaw, participants, hotelCode } = params;

  if (participants === undefined || participants === null || participants <= 0) {
    return {
      level: "unknown",
      message: "Nombre de participants inconnu",
      isRed: false,
    };
  }

  const salleConf = findSalleConfig(salleName, hotelCode);
  if (!salleConf) {
    return {
      level: "unknown",
      message: `Salle non répertoriée (${salleName || "non définie"})`,
      isRed: false,
    };
  }

  const dispoKey = normalizeDisposition(dispositionRaw);
  if (!dispoKey) {
    return {
      level: "unknown",
      message: `Disposition non reconnue (${dispositionRaw || "non définie"})`,
      isRed: false,
    };
  }

  const capacite = salleConf.capacites[dispoKey];

  // 1. Disposition non disponible dans cette salle (ex: Lille ou Brazil en board)
  if (capacite === null) {
    const proposals = getAlternativeRooms(dispoKey, participants, hotelCode);
    return {
      level: "red",
      message: `${salleConf.salle} n'est pas disponible en ${dispoKey}.`,
      proposals,
      isRed: true,
    };
  }

  // 2. Capacité dépassée
  if (participants > capacite) {
    const trop = participants - capacite;
    const proposals = getAlternativeRooms(dispoKey, participants, hotelCode);
    return {
      level: "red",
      message: `${salleConf.salle} en ${dispoKey} : ${capacite} places max pour ${participants} participants (${trop} de trop).`,
      proposals,
      isRed: true,
    };
  }

  // 3. Salle surdimensionnée (< 50% de la capacité)
  if (participants < capacite * 0.5) {
    return {
      level: "orange",
      message: `${salleConf.salle} en ${dispoKey} : ${capacite} places pour ${participants} participants, une salle plus petite suffirait.`,
      isRed: false,
    };
  }

  // 4. OK
  return {
    level: "green",
    message: `${salleConf.salle} en ${dispoKey} : ${capacite} places pour ${participants} participants.`,
    isRed: false,
  };
}

function getAlternativeRooms(
  dispoKey: DispositionKey,
  participants: number,
  hotelCode?: string
): string | undefined {
  const roomsPool = getSallesForHotel(hotelCode);
  const alternatives = roomsPool
    .filter((s) => {
      const cap = s.capacites[dispoKey];
      return cap !== null && cap >= participants;
    })
    .sort((a, b) => {
      const capA = a.capacites[dispoKey] ?? 0;
      const capB = b.capacites[dispoKey] ?? 0;
      return capA - capB;
    });

  if (alternatives.length === 0) {
    return `Aucune salle disponible en ${dispoKey} pour ${participants} pers.`;
  }

  const desc = alternatives
    .map(
      (s) =>
        `${s.salle} (${s.capacites[dispoKey]} places, ${s.prix_journee.toLocaleString("fr-FR")} €/jour)`
    )
    .join(", ");

  return `Salles possibles en ${dispoKey} pour ${participants} pers. : ${desc}.`;
}
